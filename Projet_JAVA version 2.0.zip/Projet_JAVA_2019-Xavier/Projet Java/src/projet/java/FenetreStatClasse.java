/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author vithu
 */
public class FenetreStatClasse implements ActionListener{
    //Attributs
    //Fenetre FenetreStatIndividus (Fenetre principale de cette classe)
    private final JFrame f = new JFrame("Part d'élèves dans une classe");
    //Boutons pour les differentes classes
    private final JButton b1 = new JButton("ING 1");
    private final JButton b2 = new JButton("ING 2");
    private final JButton b3 = new JButton("ING 3");
    private final JButton b4 = new JButton("ING 4");
    private final JButton b5 = new JButton("ING 5");
    //Variables necessaires
    public int anneeScolaire = 2019;
    DAO_Eleve dao_eleve = new DAO_Eleve();

    
    /**
     * Constructeur par défaut
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public FenetreStatClasse() throws ClassNotFoundException, SQLException {

        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //Fermeture de la fenetre si bouton croix rouge cliqué
        f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        Box boxV = Box.createVerticalBox();
        f.getContentPane().add(boxV, BorderLayout.CENTER);

        //Ajout de 5 boutons pour les 5 classes
        Font fontBoutton = new Font(" TimesRoman ",Font.PLAIN,20); 
        //Box horizontal dans lequel on va mettre nos 5 boutons
        Box box = Box.createHorizontalBox();
        //on fixe les paramètres de la police du bouton 1
        b1.setFont(fontBoutton);
        b1.setForeground(Color.black);
        b1.setPreferredSize(new Dimension(100, 40));
        JPanel p1 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p1.add(b1);
        p1.setBackground(Color.white);
        box.add(p1);
        //Listener si le bouton est cliqué 
        b1.addActionListener(this);

        //on fixe les paramètres de la police du bouton 2
        b2.setFont(fontBoutton);
        b2.setForeground(Color.black);
        b2.setPreferredSize(new Dimension(100, 40));
        JPanel p2 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p2.add(b2);
        p2.setBackground(Color.white);
        box.add(p2);
        //Listener si le bouton est cliqué 
        b2.addActionListener(this);

        //on fixe les paramètres de la police du bouton 1
        b3.setFont(fontBoutton);
        b3.setForeground(Color.black);
        b3.setPreferredSize(new Dimension(100, 40));
        JPanel p3 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p3.add(b3);
        p3.setBackground(Color.white);
        box.add(p3);
        //Listener si le bouton est cliqué 
        b3.addActionListener(this);

        //on fixe les paramètres de la police du bouton 1
        b4.setFont(fontBoutton);
        b4.setForeground(Color.black);
        b4.setPreferredSize(new Dimension(100, 40));
        JPanel p4 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p4.add(b4);
        p4.setBackground(Color.white);
        box.add(p4);
        //Listener si le bouton est cliqué 
        b4.addActionListener(this);

        //on fixe les paramètres de la police du bouton 1
        b5.setFont(fontBoutton);
        b5.setForeground(Color.black);
        b5.setPreferredSize(new Dimension(100, 40));
        JPanel p5 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p5.add(b5);
        p5.setBackground(Color.white);
        box.add(p5);
        //Listener si le bouton est cliqué 
        b5.addActionListener(this);

        //On ajoute le box horizontal au box principal vertical 
        boxV.add(box);

        //on recupere le nombre d'eleves dans un niveau donne

        //on recupere le nombre d'eleves dans chaque niveau donne
         //Création Histogramme
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        //on entre le nombre d'eleves dans le niveau 1
        dataset.addValue(dao_eleve.nbElevesClasse(1,1, anneeScolaire), "TD1", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesClasse(2,1, anneeScolaire), "TD2", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesClasse(3,1, anneeScolaire), "TD3", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesClasse(4,1, anneeScolaire), "TD4", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesClasse(5,1, anneeScolaire), "TD5", Integer.toString(anneeScolaire));
        //initialisation du JFreeChart en fonction du niveau demandé   
        JFreeChart histChart = ChartFactory.createBarChart("Part d'élèves en ING1", "", "Nombres d'élèves", dataset, PlotOrientation.VERTICAL, true, true, false);
        ChartPanel histPanel = new ChartPanel(histChart);
        boxV.add(histPanel);

        //fenetre rendu visible
        f.setVisible(true);
    
    }
    /**
     * Constructeur avec parametre niveau
     * @param niveau
     * @param anneeScolaire 
     * @throws ClassNotFoundException
     * @throws SQLException 
     */
    public FenetreStatClasse(int niveau, int anneeScolaire) throws ClassNotFoundException, SQLException {

        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //Fermeture de la fenetre si bouton croix rouge cliqué
        f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        Box boxV = Box.createVerticalBox();
        f.getContentPane().add(boxV, BorderLayout.CENTER);

        //Ajout de 5 boutons pour les 5 classes
        Font fontBoutton = new Font(" TimesRoman ",Font.PLAIN,20); 
        //Box horizontal dans lequel on va mettre nos 5 boutons
        Box box = Box.createHorizontalBox();
        //on fixe les paramètres de la police du bouton 1
        b1.setFont(fontBoutton);
        b1.setForeground(Color.black);
        b1.setPreferredSize(new Dimension(100, 40));
        JPanel p1 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p1.add(b1);
        p1.setBackground(Color.white);
        box.add(p1);
        //Listener si le bouton est cliqué 
        b1.addActionListener(this);

        //on fixe les paramètres de la police du bouton 2
        b2.setFont(fontBoutton);
        b2.setForeground(Color.black);
        b2.setPreferredSize(new Dimension(100, 40));
        JPanel p2 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p2.add(b2);
        p2.setBackground(Color.white);
        box.add(p2);
        //Listener si le bouton est cliqué 
        b2.addActionListener(this);

        //on fixe les paramètres de la police du bouton 1
        b3.setFont(fontBoutton);
        b3.setForeground(Color.black);
        b3.setPreferredSize(new Dimension(100, 40));
        JPanel p3 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p3.add(b3);
        p3.setBackground(Color.white);
        box.add(p3);
        //Listener si le bouton est cliqué 
        b3.addActionListener(this);

        //on fixe les paramètres de la police du bouton 1
        b4.setFont(fontBoutton);
        b4.setForeground(Color.black);
        b4.setPreferredSize(new Dimension(100, 40));
        JPanel p4 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p4.add(b4);
        p4.setBackground(Color.white);
        box.add(p4);
        //Listener si le bouton est cliqué 
        b4.addActionListener(this);

        //on fixe les paramètres de la police du bouton 1
        b5.setFont(fontBoutton);
        b5.setForeground(Color.black);
        b5.setPreferredSize(new Dimension(100, 40));
        JPanel p5 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p5.add(b5);
        p5.setBackground(Color.white);
        box.add(p5);
        //Listener si le bouton est cliqué 
        b5.addActionListener(this);

        //On ajoute le box horizontal au box principal vertical 
        boxV.add(box);

        //initialisation du JFreeChart 
        String titre = "Part d'élèves en ";
        switch (niveau) {
            case 1:
                titre += "ING1";
                int classe = 0;
                //on recupere le nombre d'eleves dans chaque niveau donne
                //Création Histogramme
                DefaultCategoryDataset dataset = new DefaultCategoryDataset();
                //on entre le nombre d'eleves dans le niveau 1
                dataset.addValue(dao_eleve.nbElevesClasse(classe+1,niveau, anneeScolaire), "TD1", Integer.toString(anneeScolaire));
                dataset.addValue(dao_eleve.nbElevesClasse(classe+2,niveau, anneeScolaire), "TD2", Integer.toString(anneeScolaire));
                dataset.addValue(dao_eleve.nbElevesClasse(classe+3,niveau, anneeScolaire), "TD3", Integer.toString(anneeScolaire));
                dataset.addValue(dao_eleve.nbElevesClasse(classe+4,niveau, anneeScolaire), "TD4", Integer.toString(anneeScolaire));
                dataset.addValue(dao_eleve.nbElevesClasse(classe+5,niveau, anneeScolaire), "TD5", Integer.toString(anneeScolaire));
                JFreeChart histChart = ChartFactory.createBarChart(titre, "", "Nombres d'élèves", dataset, PlotOrientation.VERTICAL, true, true, false);
                ChartPanel histPanel = new ChartPanel(histChart);
                boxV.add(histPanel);
                break;
            case 2:
                titre += "ING2";
                int classe2 = 5;
                //on recupere le nombre d'eleves dans chaque niveau donne
                //Création Histogramme
                DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
                //on entre le nombre d'eleves dans le niveau 1
                dataset2.addValue(dao_eleve.nbElevesClasse(classe2+1,niveau, anneeScolaire), "TD1", Integer.toString(anneeScolaire));
                dataset2.addValue(dao_eleve.nbElevesClasse(classe2+2,niveau, anneeScolaire), "TD2", Integer.toString(anneeScolaire));
                dataset2.addValue(dao_eleve.nbElevesClasse(classe2+3,niveau, anneeScolaire), "TD3", Integer.toString(anneeScolaire));
                dataset2.addValue(dao_eleve.nbElevesClasse(classe2+4,niveau, anneeScolaire), "TD4", Integer.toString(anneeScolaire));
                dataset2.addValue(dao_eleve.nbElevesClasse(classe2+5,niveau, anneeScolaire), "TD5", Integer.toString(anneeScolaire));
                JFreeChart histChart2 = ChartFactory.createBarChart(titre, "", "Nombres d'élèves", dataset2, PlotOrientation.VERTICAL, true, true, false);
                ChartPanel histPanel2 = new ChartPanel(histChart2);
                boxV.add(histPanel2);
                break;
            case 3:
                titre += "ING3";
                int classe3 = 10;
                //on recupere le nombre d'eleves dans chaque niveau donne
                //Création Histogramme
                DefaultCategoryDataset dataset3 = new DefaultCategoryDataset();
                //on entre le nombre d'eleves dans le niveau 1
                dataset3.addValue(dao_eleve.nbElevesClasse(classe3+1,niveau, anneeScolaire), "TD1", Integer.toString(anneeScolaire));
                dataset3.addValue(dao_eleve.nbElevesClasse(classe3+2,niveau, anneeScolaire), "TD2", Integer.toString(anneeScolaire));
                dataset3.addValue(dao_eleve.nbElevesClasse(classe3+3,niveau, anneeScolaire), "TD3", Integer.toString(anneeScolaire));
                dataset3.addValue(dao_eleve.nbElevesClasse(classe3+4,niveau, anneeScolaire), "TD4", Integer.toString(anneeScolaire));
                dataset3.addValue(dao_eleve.nbElevesClasse(classe3+5,niveau, anneeScolaire), "TD5", Integer.toString(anneeScolaire));
                JFreeChart histChart3 = ChartFactory.createBarChart(titre, "", "Nombres d'élèves", dataset3, PlotOrientation.VERTICAL, true, true, false);
                ChartPanel histPanel3 = new ChartPanel(histChart3);
                boxV.add(histPanel3);
                break;
            case 4:
                titre += "ING4";
                int classe4 = 15;
                //on recupere le nombre d'eleves dans chaque niveau donne
                //Création Histogramme
                DefaultCategoryDataset dataset4 = new DefaultCategoryDataset();
                //on entre le nombre d'eleves dans le niveau 1
                dataset4.addValue(dao_eleve.nbElevesClasse(classe4+1,niveau, anneeScolaire), "TD1", Integer.toString(anneeScolaire));
                dataset4.addValue(dao_eleve.nbElevesClasse(classe4+2,niveau, anneeScolaire), "TD2", Integer.toString(anneeScolaire));
                dataset4.addValue(dao_eleve.nbElevesClasse(classe4+3,niveau, anneeScolaire), "TD3", Integer.toString(anneeScolaire));
                dataset4.addValue(dao_eleve.nbElevesClasse(classe4+4,niveau, anneeScolaire), "TD4", Integer.toString(anneeScolaire));
                dataset4.addValue(dao_eleve.nbElevesClasse(classe4+5,niveau, anneeScolaire), "TD5", Integer.toString(anneeScolaire));
                JFreeChart histChart4 = ChartFactory.createBarChart(titre, "", "Nombres d'élèves", dataset4, PlotOrientation.VERTICAL, true, true, false);
                ChartPanel histPanel4 = new ChartPanel(histChart4);
                boxV.add(histPanel4);
                break;
            case 5:
                titre += "ING5";
                int classe5 = 20;
                //on recupere le nombre d'eleves dans chaque niveau donne
                //Création Histogramme
                DefaultCategoryDataset dataset5 = new DefaultCategoryDataset();
                //on entre le nombre d'eleves dans le niveau 1
                dataset5.addValue(dao_eleve.nbElevesClasse(classe5+1,niveau, anneeScolaire), "TD1", Integer.toString(anneeScolaire));
                dataset5.addValue(dao_eleve.nbElevesClasse(classe5+2,niveau, anneeScolaire), "TD2", Integer.toString(anneeScolaire));
                dataset5.addValue(dao_eleve.nbElevesClasse(classe5+3,niveau, anneeScolaire), "TD3", Integer.toString(anneeScolaire));
                dataset5.addValue(dao_eleve.nbElevesClasse(classe5+4,niveau, anneeScolaire), "TD4", Integer.toString(anneeScolaire));
                dataset5.addValue(dao_eleve.nbElevesClasse(classe5+5,niveau, anneeScolaire), "TD5", Integer.toString(anneeScolaire));
                JFreeChart histChart5 = ChartFactory.createBarChart(titre, "", "Nombres d'élèves", dataset5, PlotOrientation.VERTICAL, true, true, false);
                ChartPanel histPanel5 = new ChartPanel(histChart5);
                boxV.add(histPanel5);
                break;
            default:
                break;
        }
        

        //fenetre rendu visible
        f.setVisible(true);
    
    }
    
    //Méthodes
    /**
     * Getter fenetre
     * @return Fenetre
     */
    public JFrame getFenetre(){
        return this.f;
    }

    @Override
    //actions spécifiques à effectuées suite à un "click" sur l'un des boutons
    public void actionPerformed(ActionEvent e) {
        //f.setVisible(false);
        
        //Bouton "ING1" cliqué
        if ((JButton) e.getSource() == b1){
            try {
                f.setVisible(false);
                anneeScolaire = 2019;
                int niveau = 1;
                FentreRefresh fen= new FentreRefresh(niveau, anneeScolaire);
            } 
            catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } 
            catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        }
        //Bouton "ING2 cliqué
        else if ((JButton) e.getSource() == b2)
            try {
                f.setVisible(false);
                anneeScolaire = 2019;
                int niveau = 2;
                FentreRefresh fen= new FentreRefresh(niveau, anneeScolaire);
            } 
            catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } 
            catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        
        //Bouton "ING3" cliqué
        else if ((JButton) e.getSource() == b3)
            try {
                f.setVisible(false);
                anneeScolaire = 2019;
                int niveau = 3;
                FentreRefresh fen= new FentreRefresh(niveau, anneeScolaire);
            } 
            catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } 
            catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        
        //Bouton "ING4" cliqué
        else if ((JButton) e.getSource() == b4)
            try {
                f.setVisible(false);
                anneeScolaire = 2019;
                int niveau = 4;
                FentreRefresh fen= new FentreRefresh(niveau, anneeScolaire);
            } 
            catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } 
            catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        
        //Bouton "ING5" cliqué
        else if ((JButton) e.getSource() == b5)
            try {
                f.setVisible(false);
                anneeScolaire = 2019;
                int niveau = 5;
                FentreRefresh fen= new FentreRefresh(niveau, anneeScolaire);
            } 
            catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } 
            catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
            
    }

}
