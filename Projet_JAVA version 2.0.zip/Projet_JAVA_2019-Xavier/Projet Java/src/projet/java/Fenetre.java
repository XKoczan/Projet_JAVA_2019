/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import javax.swing.JFrame;

/**
 *
 * @author xavie
 */
public class Fenetre {

    JFrame frame = new JFrame();

    public Fenetre() {
        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
