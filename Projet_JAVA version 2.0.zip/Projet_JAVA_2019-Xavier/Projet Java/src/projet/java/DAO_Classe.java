/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 *
 * @author vithu
 */
public class DAO_Classe extends DAO<Classe> {
    
    //Constructeurs
    public DAO_Classe() {
        super();
        chargement();
    }
    
    @Override
    public void creer(Classe obj, int a) {
        try {
            //ajout de la classe dans table "classe"
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO tab_classe(classe_nom) values(?)");
            stmt.setObject(1, obj.getNom(), Types.VARCHAR);
            stmt.executeUpdate();
            
        } catch (SQLException ex) {
            System.out.println("Probleme de creation de discipline");
        }
    }

    @Override
    public void supprimer(Classe obj) {
        try {
            
            PreparedStatement stmt = conn.prepareStatement("SELECT classe_id FROM tab_classe WHERE inscription_personne_id = ?");
//           System.out.println("1");//Test
            stmt.setObject(1, obj.getId());
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int id2 = rs.getInt("inscription_id");

            stmt = conn.prepareStatement("DELETE FROM tab_bulletin where bulletin_inscription_id = ?");
            stmt.setObject(1, id2, Types.INTEGER);
            stmt.executeUpdate();

            stmt = conn.prepareStatement("DELETE FROM tab_inscription where inscription_personne_id = ?");
            stmt.setObject(1, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

            stmt = conn.prepareStatement("DELETE FROM tab_personne where personne_id = ?");
            stmt.setObject(1, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Probleme de suppression de discipline");
        }
    }

    @Override
    public void modifier(Classe obj) {
         try {

            // ID ave cla classe ELeve
//            id = obj.getId();
            PreparedStatement stmt = conn.prepareStatement("Update tab_disicpline set discipline_nom = ?  where discipline_id = ? ");
            stmt.setObject(1, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Probleme de modification de la discipline");
        }
    }

    @Override
    public void chargement() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
