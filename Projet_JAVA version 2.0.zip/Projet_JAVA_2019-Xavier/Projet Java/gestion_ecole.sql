-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  sam. 08 juin 2019 à 18:21
-- Version du serveur :  5.7.23
-- Version de PHP :  7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestion_ecole`
--

-- --------------------------------------------------------

--
-- Structure de la table `tab_anneescolaire`
--

DROP TABLE IF EXISTS `tab_anneescolaire`;
CREATE TABLE IF NOT EXISTS `tab_anneescolaire` (
  `anneescolaire_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`anneescolaire_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2020 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_anneescolaire`
--

INSERT INTO `tab_anneescolaire` (`anneescolaire_id`) VALUES
(2017),
(2018),
(2019);

-- --------------------------------------------------------

--
-- Structure de la table `tab_bulletin`
--

DROP TABLE IF EXISTS `tab_bulletin`;
CREATE TABLE IF NOT EXISTS `tab_bulletin` (
  `bulletin_id` int(11) NOT NULL AUTO_INCREMENT,
  `bulletin_trimestre_id` int(11) NOT NULL,
  `bulletin_inscription_id` int(11) NOT NULL,
  `bulletin_appreciation` varchar(255) NOT NULL,
  PRIMARY KEY (`bulletin_id`),
  KEY `bulletin_inscription_id` (`bulletin_inscription_id`),
  KEY `bulletin_trimestre_id` (`bulletin_trimestre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_bulletin`
--

INSERT INTO `tab_bulletin` (`bulletin_id`, `bulletin_trimestre_id`, `bulletin_inscription_id`, `bulletin_appreciation`) VALUES
(1, 1, 4, '\"Très bien. Continuez ainsi\"'),
(2, 1, 2, '\"Moyen malgré de gros efforts\"'),
(3, 1, 3, '\"Insuffisant. Il faut travailler davantage\"'),
(4, 2, 1, '\"Légère baisse. Résultats convenables\"'),
(5, 2, 2, '\"Poursuivre vos efforts. Vous y êtes presque\"'),
(6, 2, 3, '\"Du travail fourni. Continue dans cette voie\"'),
(7, 3, 1, '\"Bravo. Excellents résultats.\"'),
(8, 3, 2, '\"Un ensemble de résultats convenables. Encourageant\"'),
(9, 3, 3, '\"Résultats très fragiles.\"');

-- --------------------------------------------------------

--
-- Structure de la table `tab_classe`
--

DROP TABLE IF EXISTS `tab_classe`;
CREATE TABLE IF NOT EXISTS `tab_classe` (
  `classe_id` int(11) NOT NULL AUTO_INCREMENT,
  `classe_nom` varchar(255) NOT NULL,
  `classe_niveau_id` int(11) NOT NULL,
  `classe_anneescolaire_id` int(11) NOT NULL,
  PRIMARY KEY (`classe_id`),
  KEY `classe_anneescolaire_id` (`classe_anneescolaire_id`),
  KEY `classe_niveau_id` (`classe_niveau_id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_classe`
--

INSERT INTO `tab_classe` (`classe_id`, `classe_nom`, `classe_niveau_id`, `classe_anneescolaire_id`) VALUES
(1, 'TD1', 1, 2019),
(2, 'TD2', 1, 2019),
(3, 'TD3', 1, 2019),
(4, 'TD4', 1, 2019),
(5, 'TD5', 1, 2019),
(6, 'TD1', 2, 2019),
(7, 'TD2', 2, 2019),
(8, 'TD3', 2, 2019),
(9, 'TD4', 2, 2019),
(10, 'TD5', 2, 2019),
(11, 'TD1', 3, 2019),
(12, 'TD2', 3, 2019),
(13, 'TD3', 3, 2019),
(14, 'TD4', 3, 2019),
(15, 'TD5', 3, 2019),
(16, 'TD1', 4, 2019),
(17, 'TD2', 4, 2019),
(18, 'TD3', 4, 2019),
(19, 'TD4', 4, 2019),
(20, 'TD5', 4, 2019),
(21, 'TD1', 5, 2019),
(22, 'TD2', 5, 2019),
(23, 'TD3', 5, 2019),
(24, 'TD4', 5, 2019),
(25, 'TD5', 5, 2019),
(26, 'TD1', 1, 2018),
(27, 'TD2', 1, 2018),
(28, 'TD3', 1, 2018),
(29, 'TD4', 1, 2018),
(30, 'TD5', 1, 2018),
(31, 'TD1', 2, 2018),
(32, 'TD2', 2, 2018),
(33, 'TD3', 2, 2018),
(34, 'TD4', 2, 2018),
(35, 'TD5', 2, 2018),
(36, 'TD1', 3, 2018),
(37, 'TD2', 3, 2018),
(38, 'TD3', 3, 2018),
(39, 'TD4', 3, 2018),
(40, 'TD5', 3, 2018),
(41, 'TD1', 4, 2018),
(42, 'TD2', 4, 2018),
(43, 'TD3', 4, 2018),
(44, 'TD4', 4, 2018),
(45, 'TD5', 4, 2018),
(46, 'TD1', 5, 2018),
(47, 'TD2', 5, 2018),
(48, 'TD3', 5, 2018),
(49, 'TD4', 5, 2018),
(50, 'TD5', 5, 2018),
(51, 'TD1', 1, 2017),
(52, 'TD2', 1, 2017),
(53, 'TD3', 1, 2017),
(54, 'TD4', 1, 2017),
(55, 'TD5', 1, 2017),
(56, 'TD1', 2, 2017),
(57, 'TD2', 2, 2017),
(58, 'TD3', 2, 2017),
(59, 'TD4', 2, 2017),
(60, 'TD5', 2, 2018),
(61, 'TD1', 3, 2017),
(62, 'TD2', 3, 2017),
(63, 'TD3', 3, 2017),
(64, 'TD4', 3, 2017),
(65, 'TD5', 3, 2017),
(66, 'TD1', 4, 2017),
(67, 'TD2', 4, 2017),
(68, 'TD3', 4, 2017),
(69, 'TD4', 4, 2017),
(70, 'TD5', 4, 2017),
(71, 'TD1', 5, 2017),
(72, 'TD2', 5, 2017),
(73, 'TD3', 5, 2017),
(74, 'TD4', 5, 2017),
(75, 'TD5', 5, 2017);

-- --------------------------------------------------------

--
-- Structure de la table `tab_detailbulletin`
--

DROP TABLE IF EXISTS `tab_detailbulletin`;
CREATE TABLE IF NOT EXISTS `tab_detailbulletin` (
  `detailbulletin_id` int(11) NOT NULL AUTO_INCREMENT,
  `detailbulletin_bulletin_id` int(11) NOT NULL,
  `detailbulletin_enseignement_id` int(11) NOT NULL,
  `detailbulletin_appreciation` varchar(255) NOT NULL,
  PRIMARY KEY (`detailbulletin_id`),
  KEY `detailbulletin_bulletin_id` (`detailbulletin_bulletin_id`),
  KEY `detailbulletin_enseignement_id` (`detailbulletin_enseignement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_detailbulletin`
--

INSERT INTO `tab_detailbulletin` (`detailbulletin_id`, `detailbulletin_bulletin_id`, `detailbulletin_enseignement_id`, `detailbulletin_appreciation`) VALUES
(1, 1, 1, '\"Elève sérieux\"'),
(2, 1, 2, '\"Résultats corrects\"'),
(3, 1, 3, '\"Travail insuffisant\"'),
(4, 1, 4, '\"Excellent\"'),
(5, 1, 5, '\"Très bien\"');

-- --------------------------------------------------------

--
-- Structure de la table `tab_discipline`
--

DROP TABLE IF EXISTS `tab_discipline`;
CREATE TABLE IF NOT EXISTS `tab_discipline` (
  `discipline_id` int(11) NOT NULL AUTO_INCREMENT,
  `discipline_nom` varchar(255) NOT NULL,
  PRIMARY KEY (`discipline_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_discipline`
--

INSERT INTO `tab_discipline` (`discipline_id`, `discipline_nom`) VALUES
(1, 'Mathématiques'),
(2, 'POO JAVA'),
(3, 'Traitement du signal'),
(4, 'Anglais'),
(5, 'Droit du Travail');

-- --------------------------------------------------------

--
-- Structure de la table `tab_enseignement`
--

DROP TABLE IF EXISTS `tab_enseignement`;
CREATE TABLE IF NOT EXISTS `tab_enseignement` (
  `enseignement_id` int(11) NOT NULL AUTO_INCREMENT,
  `enseignement_classe_id` int(11) NOT NULL,
  `enseignement_discipline_id` int(11) NOT NULL,
  `enseignement_personne_id` int(11) NOT NULL,
  PRIMARY KEY (`enseignement_id`),
  KEY `enseignement_discipline_id` (`enseignement_discipline_id`),
  KEY `enseignement_personne_id` (`enseignement_personne_id`),
  KEY `enseignement_classe_id` (`enseignement_classe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_enseignement`
--

INSERT INTO `tab_enseignement` (`enseignement_id`, `enseignement_classe_id`, `enseignement_discipline_id`, `enseignement_personne_id`) VALUES
(1, 5, 1, 6),
(2, 5, 2, 44),
(3, 5, 3, 46),
(4, 5, 4, 45),
(5, 5, 5, 48);

-- --------------------------------------------------------

--
-- Structure de la table `tab_evaluation`
--

DROP TABLE IF EXISTS `tab_evaluation`;
CREATE TABLE IF NOT EXISTS `tab_evaluation` (
  `evaluation_id` int(11) NOT NULL AUTO_INCREMENT,
  `evaluation_detailbulletin_id` int(11) NOT NULL,
  `evaluation_note` int(11) NOT NULL,
  `evaluation_appreciation` varchar(255) NOT NULL,
  PRIMARY KEY (`evaluation_id`),
  KEY `evaluation_detailbulletin_id` (`evaluation_detailbulletin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_evaluation`
--

INSERT INTO `tab_evaluation` (`evaluation_id`, `evaluation_detailbulletin_id`, `evaluation_note`, `evaluation_appreciation`) VALUES
(1, 1, 14, 'Bien'),
(2, 2, 11, 'Convenable'),
(3, 3, 6, 'Retravaillez ce sujet'),
(4, 4, 18, 'Très bien'),
(5, 5, 17, 'Poursuivre comme cela'),
(6, 1, 13, 'Continuez ainsi');

-- --------------------------------------------------------

--
-- Structure de la table `tab_inscription`
--

DROP TABLE IF EXISTS `tab_inscription`;
CREATE TABLE IF NOT EXISTS `tab_inscription` (
  `inscription_id` int(11) NOT NULL AUTO_INCREMENT,
  `inscription_classe_id` int(11) NOT NULL,
  `inscription_personne_id` int(11) NOT NULL,
  PRIMARY KEY (`inscription_id`),
  KEY `inscription_personne_id` (`inscription_personne_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_inscription`
--

INSERT INTO `tab_inscription` (`inscription_id`, `inscription_classe_id`, `inscription_personne_id`) VALUES
(1, 1, 3),
(2, 1, 4),
(3, 2, 2),
(4, 3, 1),
(5, 3, 5),
(6, 3, 7),
(7, 4, 8),
(8, 4, 9),
(9, 5, 10),
(10, 6, 11),
(11, 6, 12),
(12, 7, 13),
(13, 8, 14),
(14, 17, 15),
(15, 8, 16),
(16, 9, 17),
(17, 10, 18),
(18, 11, 19),
(19, 12, 20),
(20, 13, 21),
(21, 14, 22),
(22, 14, 23),
(23, 15, 24),
(24, 16, 25),
(25, 19, 26),
(26, 18, 27),
(27, 19, 28),
(28, 19, 29),
(29, 20, 30),
(30, 21, 31),
(31, 22, 32),
(32, 22, 33),
(33, 23, 34),
(34, 25, 35),
(35, 26, 36),
(36, 27, 37),
(37, 28, 38),
(38, 29, 39),
(39, 30, 40),
(40, 7, 43),
(41, 7, 42),
(42, 16, 41),
(43, 24, 47);

-- --------------------------------------------------------

--
-- Structure de la table `tab_niveau`
--

DROP TABLE IF EXISTS `tab_niveau`;
CREATE TABLE IF NOT EXISTS `tab_niveau` (
  `niveau_id` int(11) NOT NULL AUTO_INCREMENT,
  `niveau_nom` int(11) NOT NULL,
  PRIMARY KEY (`niveau_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_niveau`
--

INSERT INTO `tab_niveau` (`niveau_id`, `niveau_nom`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);

-- --------------------------------------------------------

--
-- Structure de la table `tab_personne`
--

DROP TABLE IF EXISTS `tab_personne`;
CREATE TABLE IF NOT EXISTS `tab_personne` (
  `personne_id` int(11) NOT NULL AUTO_INCREMENT,
  `personne_nom` varchar(255) NOT NULL,
  `personne_prenom` varchar(255) NOT NULL,
  `personne_type` varchar(255) NOT NULL,
  PRIMARY KEY (`personne_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_personne`
--

INSERT INTO `tab_personne` (`personne_id`, `personne_nom`, `personne_prenom`, `personne_type`) VALUES
(1, 'Marchand', 'Josephine', 'etu'),
(2, 'john ', 'JILLES', 'etu'),
(3, 'lolo', 'lili', 'etu'),
(4, 'jules', 'bernard', 'etu'),
(5, 'Mohammed', 'Amin', 'etu'),
(6, 'Le Cor', 'Marc', 'prof'),
(7, 'Paul', 'Joseph', 'etu'),
(8, 'Olivier', 'Patrick', 'etu'),
(9, 'Fontaine', 'Claire', 'etu'),
(10, 'Marlaud', 'Georges', 'etu'),
(11, 'Jean', 'Jacques', 'etu'),
(12, 'Martin', 'Pauline', 'etu'),
(13, 'Poirier', 'Vincent', 'etu'),
(14, 'Sabbam', 'Christine', 'etu'),
(15, 'Perrine', 'Hugo', 'etu'),
(16, 'Wang', 'Celine', 'etu'),
(17, 'Frenet', 'Arthur', 'etu'),
(18, 'Raymond', 'François', 'etu'),
(19, 'Ulysse', 'Remo', 'etu'),
(20, 'Nicolas', 'John', 'etu'),
(21, 'Melowa', 'Astrid', 'etu'),
(22, 'Carlos', 'Georgiana', 'etu'),
(23, 'Thomas', 'Victor', 'etu'),
(24, 'Mike', 'Jack', 'etu'),
(25, 'Joan', 'Carlito', 'etu'),
(26, 'Philippe', 'Pierre', 'etu'),
(27, 'Zendaya', 'Safia', 'etu'),
(28, 'Merlin', 'Laetitia', 'etu'),
(29, 'Savoie', 'Susane', 'etu'),
(30, 'Lucas', 'Leonard', 'etu'),
(31, 'Hugo', 'Cyprien', 'etu'),
(32, 'Laplace', 'Monica', 'etu'),
(33, 'Yohan', 'Rayan', 'etu'),
(34, 'Redouane', 'Lea', 'etu'),
(35, 'Marcel', 'Tibault', 'etu'),
(36, 'Arnaud', 'Estelle', 'etu'),
(37, 'Pierrot', 'Isabelle', 'etu'),
(38, 'James', 'Mickaela', 'etu'),
(39, 'Laurent', 'Laurence', 'etu'),
(40, 'Damien', 'Julie', 'etu'),
(41, 'Koczan', 'Xavier', 'etu'),
(42, 'Le Loher', 'Guillaume', 'etu'),
(43, 'Sivakumaran', 'Vithusha', 'etu'),
(44, 'Le Lievre', 'Baptiste', 'prof'),
(45, 'Rauzier', 'Juliette', 'prof'),
(46, 'Cotier', 'Charlie', 'prof'),
(47, 'Poitier', 'Helene', 'etu'),
(48, 'Rodriguez', 'Elena', 'prof');

-- --------------------------------------------------------

--
-- Structure de la table `tab_trimestre`
--

DROP TABLE IF EXISTS `tab_trimestre`;
CREATE TABLE IF NOT EXISTS `tab_trimestre` (
  `trimestre_id` int(11) NOT NULL AUTO_INCREMENT,
  `trimestre_numero` int(11) NOT NULL,
  `trimestre_debut` int(11) NOT NULL,
  `trimestre_fin` int(11) NOT NULL,
  `trimestre_annescolaire_id` int(11) NOT NULL,
  PRIMARY KEY (`trimestre_id`),
  KEY `trimestre_annescolaire_id` (`trimestre_annescolaire_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_trimestre`
--

INSERT INTO `tab_trimestre` (`trimestre_id`, `trimestre_numero`, `trimestre_debut`, `trimestre_fin`, `trimestre_annescolaire_id`) VALUES
(1, 1, 9, 12, 2019),
(2, 2, 1, 3, 2019),
(3, 3, 4, 6, 2019);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tab_bulletin`
--
ALTER TABLE `tab_bulletin`
  ADD CONSTRAINT `tab_bulletin_ibfk_1` FOREIGN KEY (`bulletin_inscription_id`) REFERENCES `tab_inscription` (`inscription_id`),
  ADD CONSTRAINT `tab_bulletin_ibfk_2` FOREIGN KEY (`bulletin_trimestre_id`) REFERENCES `tab_trimestre` (`trimestre_id`);

--
-- Contraintes pour la table `tab_classe`
--
ALTER TABLE `tab_classe`
  ADD CONSTRAINT `tab_classe_ibfk_1` FOREIGN KEY (`classe_anneescolaire_id`) REFERENCES `tab_anneescolaire` (`anneescolaire_id`),
  ADD CONSTRAINT `tab_classe_ibfk_3` FOREIGN KEY (`classe_niveau_id`) REFERENCES `tab_niveau` (`niveau_id`);

--
-- Contraintes pour la table `tab_detailbulletin`
--
ALTER TABLE `tab_detailbulletin`
  ADD CONSTRAINT `tab_detailbulletin_ibfk_1` FOREIGN KEY (`detailbulletin_bulletin_id`) REFERENCES `tab_bulletin` (`bulletin_id`),
  ADD CONSTRAINT `tab_detailbulletin_ibfk_2` FOREIGN KEY (`detailbulletin_enseignement_id`) REFERENCES `tab_enseignement` (`enseignement_id`);

--
-- Contraintes pour la table `tab_enseignement`
--
ALTER TABLE `tab_enseignement`
  ADD CONSTRAINT `tab_enseignement_ibfk_2` FOREIGN KEY (`enseignement_discipline_id`) REFERENCES `tab_discipline` (`discipline_id`),
  ADD CONSTRAINT `tab_enseignement_ibfk_3` FOREIGN KEY (`enseignement_personne_id`) REFERENCES `tab_personne` (`personne_id`),
  ADD CONSTRAINT `tab_enseignement_ibfk_4` FOREIGN KEY (`enseignement_classe_id`) REFERENCES `tab_classe` (`classe_id`);

--
-- Contraintes pour la table `tab_evaluation`
--
ALTER TABLE `tab_evaluation`
  ADD CONSTRAINT `tab_evaluation_ibfk_1` FOREIGN KEY (`evaluation_detailbulletin_id`) REFERENCES `tab_detailbulletin` (`detailbulletin_id`);

--
-- Contraintes pour la table `tab_inscription`
--
ALTER TABLE `tab_inscription`
  ADD CONSTRAINT `tab_inscription_ibfk_2` FOREIGN KEY (`inscription_personne_id`) REFERENCES `tab_personne` (`personne_id`);

--
-- Contraintes pour la table `tab_trimestre`
--
ALTER TABLE `tab_trimestre`
  ADD CONSTRAINT `tab_trimestre_ibfk_1` FOREIGN KEY (`trimestre_annescolaire_id`) REFERENCES `tab_anneescolaire` (`anneescolaire_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
