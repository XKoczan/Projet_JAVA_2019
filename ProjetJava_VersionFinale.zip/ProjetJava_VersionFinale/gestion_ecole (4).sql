-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  Dim 09 juin 2019 à 15:45
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestion_ecole`
--

-- --------------------------------------------------------

--
-- Structure de la table `tab_anneescolaire`
--

DROP TABLE IF EXISTS `tab_anneescolaire`;
CREATE TABLE IF NOT EXISTS `tab_anneescolaire` (
  `anneescolaire_id` int(11) NOT NULL,
  PRIMARY KEY (`anneescolaire_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_anneescolaire`
--

INSERT INTO `tab_anneescolaire` (`anneescolaire_id`) VALUES
(2018),
(2019);

-- --------------------------------------------------------

--
-- Structure de la table `tab_bulletin`
--

DROP TABLE IF EXISTS `tab_bulletin`;
CREATE TABLE IF NOT EXISTS `tab_bulletin` (
  `bulletin_id` int(11) NOT NULL AUTO_INCREMENT,
  `bulletin_trimestre_id` int(11) NOT NULL,
  `bulletin_inscription_id` int(11) NOT NULL,
  `bulletin_appreciation` varchar(255) NOT NULL,
  PRIMARY KEY (`bulletin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_bulletin`
--

INSERT INTO `tab_bulletin` (`bulletin_id`, `bulletin_trimestre_id`, `bulletin_inscription_id`, `bulletin_appreciation`) VALUES
(138, 1, 66, 'A renseigner'),
(139, 2, 66, 'A renseigner'),
(140, 3, 66, 'A renseigner'),
(141, 1, 67, 'A renseigner'),
(142, 2, 67, 'A renseigner'),
(143, 3, 67, 'A renseigner'),
(144, 1, 68, 'A renseigner'),
(145, 2, 68, 'A renseigner'),
(146, 3, 68, 'A renseigner'),
(162, 1, 74, 'A renseigner'),
(163, 2, 74, 'A renseigner'),
(164, 3, 74, 'A renseigner'),
(165, 1, 75, 'A renseigner'),
(166, 2, 75, 'A renseigner'),
(167, 3, 75, 'A renseigner'),
(171, 1, 77, 'A renseigner'),
(172, 2, 77, 'A renseigner'),
(173, 3, 77, 'A renseigner'),
(174, 1, 78, 'A renseigner'),
(175, 2, 78, 'A renseigner'),
(176, 3, 78, 'A renseigner'),
(177, 1, 79, 'A renseigner'),
(178, 2, 79, 'A renseigner'),
(179, 3, 79, 'A renseigner'),
(180, 1, 80, 'A renseigner'),
(181, 2, 80, 'A renseigner'),
(182, 3, 80, 'A renseigner'),
(183, 1, 81, 'A renseigner'),
(184, 2, 81, 'A renseigner'),
(185, 3, 81, 'A renseigner'),
(186, 1, 82, 'A renseigner'),
(187, 2, 82, 'A renseigner'),
(188, 3, 82, 'A renseigner'),
(189, 1, 83, 'A renseigner'),
(190, 2, 83, 'A renseigner'),
(191, 3, 83, 'A renseigner'),
(192, 1, 84, 'A renseigner'),
(193, 2, 84, 'A renseigner'),
(194, 3, 84, 'A renseigner'),
(195, 1, 85, 'A renseigner'),
(196, 2, 85, 'A renseigner'),
(197, 3, 85, 'A renseigner'),
(198, 1, 86, 'A renseigner'),
(199, 2, 86, 'A renseigner'),
(200, 3, 86, 'A renseigner'),
(201, 1, 87, 'A renseigner'),
(202, 2, 87, 'A renseigner'),
(203, 3, 87, 'A renseigner'),
(204, 1, 88, 'A renseigner'),
(205, 2, 88, 'A renseigner'),
(206, 3, 88, 'A renseigner'),
(207, 1, 89, 'A renseigner'),
(208, 2, 89, 'A renseigner'),
(209, 3, 89, 'A renseigner'),
(210, 1, 90, 'A renseigner'),
(211, 2, 90, 'A renseigner'),
(212, 3, 90, 'A renseigner'),
(213, 1, 91, 'A renseigner'),
(214, 2, 91, 'A renseigner'),
(215, 3, 91, 'A renseigner'),
(216, 1, 92, 'A renseigner'),
(217, 2, 92, 'A renseigner'),
(218, 3, 92, 'A renseigner'),
(219, 1, 93, 'A renseigner'),
(220, 2, 93, 'A renseigner'),
(221, 3, 93, 'A renseigner'),
(222, 1, 94, 'A renseigner'),
(223, 2, 94, 'A renseigner'),
(224, 3, 94, 'A renseigner'),
(225, 1, 95, 'A renseigner'),
(226, 2, 95, 'A renseigner'),
(227, 3, 95, 'A renseigner'),
(228, 1, 96, 'A renseigner'),
(229, 2, 96, 'A renseigner'),
(230, 3, 96, 'A renseigner'),
(231, 1, 97, 'A renseigner'),
(232, 2, 97, 'A renseigner'),
(233, 3, 97, 'A renseigner'),
(234, 1, 98, 'A renseigner'),
(235, 2, 98, 'A renseigner'),
(236, 3, 98, 'A renseigner'),
(237, 1, 99, 'A renseigner'),
(238, 2, 99, 'A renseigner'),
(239, 3, 99, 'A renseigner'),
(240, 1, 100, 'A renseigner'),
(241, 2, 100, 'A renseigner'),
(242, 3, 100, 'A renseigner'),
(243, 1, 101, 'A renseigner'),
(244, 2, 101, 'A renseigner'),
(245, 3, 101, 'A renseigner'),
(246, 1, 102, 'A renseigner'),
(247, 2, 102, 'A renseigner'),
(248, 3, 102, 'A renseigner'),
(249, 1, 103, 'A renseigner'),
(250, 2, 103, 'A renseigner'),
(251, 3, 103, 'A renseigner'),
(252, 1, 104, 'A renseigner'),
(253, 2, 104, 'A renseigner'),
(254, 3, 104, 'A renseigner'),
(255, 1, 105, 'A renseigner'),
(256, 2, 105, 'A renseigner'),
(257, 3, 105, 'A renseigner'),
(258, 1, 106, 'A renseigner'),
(259, 2, 106, 'A renseigner'),
(260, 3, 106, 'A renseigner'),
(261, 1, 107, 'A renseigner'),
(262, 2, 107, 'A renseigner'),
(263, 3, 107, 'A renseigner'),
(264, 1, 108, 'A renseigner'),
(265, 2, 108, 'A renseigner'),
(266, 3, 108, 'A renseigner'),
(267, 1, 109, 'A renseigner'),
(268, 2, 109, 'A renseigner'),
(269, 3, 109, 'A renseigner'),
(270, 1, 110, 'A renseigner'),
(271, 2, 110, 'A renseigner'),
(272, 3, 110, 'A renseigner'),
(273, 1, 111, 'A renseigner'),
(274, 2, 111, 'A renseigner'),
(275, 3, 111, 'A renseigner'),
(279, 1, 113, 'A renseigner'),
(280, 2, 113, 'A renseigner'),
(281, 3, 113, 'A renseigner'),
(282, 1, 114, 'A renseigner'),
(283, 2, 114, 'A renseigner'),
(284, 3, 114, 'A renseigner');

-- --------------------------------------------------------

--
-- Structure de la table `tab_classe`
--

DROP TABLE IF EXISTS `tab_classe`;
CREATE TABLE IF NOT EXISTS `tab_classe` (
  `classe_id` int(11) NOT NULL AUTO_INCREMENT,
  `classe_nom` varchar(255) NOT NULL,
  `classe_niveau_id` int(11) NOT NULL,
  `classe_anneescolaire_id` int(11) NOT NULL,
  PRIMARY KEY (`classe_id`),
  KEY `classe_niveau_id` (`classe_niveau_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_classe`
--

INSERT INTO `tab_classe` (`classe_id`, `classe_nom`, `classe_niveau_id`, `classe_anneescolaire_id`) VALUES
(1, 'TD1', 1, 2019),
(2, 'TD2', 1, 2019),
(3, 'TD3', 1, 2019),
(4, 'TD4', 1, 2019),
(5, 'TD5', 1, 2019),
(6, 'TD1', 2, 2019),
(7, 'TD2', 2, 2019),
(8, 'TD3', 2, 2019),
(9, 'TD4', 2, 2019),
(10, 'TD5', 2, 2019),
(11, 'TD1', 3, 2019),
(12, 'TD2', 3, 2019),
(13, 'TD3', 3, 2019),
(14, 'TD4', 3, 2019),
(15, 'TD5', 3, 2019),
(16, 'TD1', 4, 2019),
(17, 'TD2', 4, 2019),
(18, 'TD3', 4, 2019),
(19, 'TD4', 4, 2019),
(20, 'TD5', 4, 2019),
(21, 'TD1', 5, 2019),
(22, 'TD2', 5, 2019),
(23, 'TD3', 5, 2019),
(24, 'TD4', 5, 2019),
(25, 'TD5', 5, 2019),
(26, 'TD5', 5, 2018),
(27, 'TD5', 1, 2018);

-- --------------------------------------------------------

--
-- Structure de la table `tab_detailbulletin`
--

DROP TABLE IF EXISTS `tab_detailbulletin`;
CREATE TABLE IF NOT EXISTS `tab_detailbulletin` (
  `detailbulletin_id` int(11) NOT NULL AUTO_INCREMENT,
  `detailbulletin_bulletin_id` int(11) NOT NULL,
  `detailbulletin_enseignement_id` int(11) NOT NULL,
  `detailbulletin_appreciation` varchar(255) NOT NULL,
  PRIMARY KEY (`detailbulletin_id`),
  KEY `detailbulletin_bulletin_id` (`detailbulletin_bulletin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_detailbulletin`
--

INSERT INTO `tab_detailbulletin` (`detailbulletin_id`, `detailbulletin_bulletin_id`, `detailbulletin_enseignement_id`, `detailbulletin_appreciation`) VALUES
(110, 162, 28, 'A renseigner'),
(111, 162, 29, 'A renseigner'),
(112, 163, 28, 'A renseigner'),
(113, 163, 29, 'A renseigner'),
(114, 164, 28, 'A renseigner'),
(115, 164, 29, 'A renseigner'),
(125, 171, 33, 'A renseigner'),
(126, 171, 34, 'A renseigner'),
(127, 171, 35, 'A renseigner'),
(128, 172, 33, 'A renseigner'),
(129, 172, 34, 'A renseigner'),
(130, 172, 35, 'A renseigner'),
(131, 173, 33, 'A renseigner'),
(132, 173, 34, 'A renseigner'),
(133, 173, 35, 'A renseigner'),
(134, 174, 33, 'A renseigner'),
(135, 174, 34, 'A renseigner'),
(136, 174, 35, 'A renseigner'),
(137, 175, 33, 'A renseigner'),
(138, 175, 34, 'A renseigner'),
(139, 175, 35, 'A renseigner'),
(140, 176, 33, 'A renseigner'),
(141, 176, 34, 'A renseigner'),
(142, 176, 35, 'A renseigner'),
(143, 177, 33, 'A renseigner'),
(144, 177, 34, 'A renseigner'),
(145, 177, 35, 'A renseigner'),
(146, 178, 33, 'A renseigner'),
(147, 178, 34, 'A renseigner'),
(148, 178, 35, 'A renseigner'),
(149, 179, 33, 'A renseigner'),
(150, 179, 34, 'A renseigner'),
(151, 179, 35, 'A renseigner'),
(155, 279, 37, 'A renseigner'),
(156, 280, 37, 'A renseigner'),
(157, 281, 37, 'A renseigner'),
(158, 282, 38, 'A renseigner'),
(159, 283, 38, 'A renseigner'),
(160, 284, 38, 'A renseigner');

-- --------------------------------------------------------

--
-- Structure de la table `tab_discipline`
--

DROP TABLE IF EXISTS `tab_discipline`;
CREATE TABLE IF NOT EXISTS `tab_discipline` (
  `discipline_id` int(11) NOT NULL AUTO_INCREMENT,
  `discipline_nom` varchar(255) NOT NULL,
  PRIMARY KEY (`discipline_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_discipline`
--

INSERT INTO `tab_discipline` (`discipline_id`, `discipline_nom`) VALUES
(8, 'POO JAVA'),
(9, 'Mathematiques'),
(10, 'Anglais');

-- --------------------------------------------------------

--
-- Structure de la table `tab_enseignement`
--

DROP TABLE IF EXISTS `tab_enseignement`;
CREATE TABLE IF NOT EXISTS `tab_enseignement` (
  `enseignement_id` int(11) NOT NULL AUTO_INCREMENT,
  `enseignement_classe_id` int(11) NOT NULL,
  `enseignement_discipline_id` int(11) NOT NULL,
  `enseignement_personne_id` int(11) NOT NULL,
  PRIMARY KEY (`enseignement_id`),
  KEY `enseignement_personne_id` (`enseignement_personne_id`),
  KEY `enseignement_discipline_id` (`enseignement_discipline_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_enseignement`
--

INSERT INTO `tab_enseignement` (`enseignement_id`, `enseignement_classe_id`, `enseignement_discipline_id`, `enseignement_personne_id`) VALUES
(33, 1, 8, 140),
(34, 1, 9, 141),
(35, 1, 10, 142),
(37, 26, 9, 181),
(38, 27, 10, 183);

-- --------------------------------------------------------

--
-- Structure de la table `tab_evaluation`
--

DROP TABLE IF EXISTS `tab_evaluation`;
CREATE TABLE IF NOT EXISTS `tab_evaluation` (
  `evaluation_id` int(11) NOT NULL AUTO_INCREMENT,
  `evaluation_detailbulletin_id` int(11) NOT NULL,
  `evaluation_note` int(11) DEFAULT NULL,
  `evaluation_appreciation` varchar(255) NOT NULL,
  PRIMARY KEY (`evaluation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_evaluation`
--

INSERT INTO `tab_evaluation` (`evaluation_id`, `evaluation_detailbulletin_id`, `evaluation_note`, `evaluation_appreciation`) VALUES
(150, 110, NULL, 'A renseigner'),
(151, 111, NULL, 'A renseigner'),
(152, 112, NULL, 'A renseigner'),
(153, 113, NULL, 'A renseigner'),
(154, 114, NULL, 'A renseigner'),
(155, 115, NULL, 'A renseigner'),
(165, 125, NULL, 'A renseigner'),
(166, 126, NULL, 'A renseigner'),
(167, 127, NULL, 'A renseigner'),
(168, 128, NULL, 'A renseigner'),
(169, 129, NULL, 'A renseigner'),
(170, 130, NULL, 'A renseigner'),
(171, 131, NULL, 'A renseigner'),
(172, 132, NULL, 'A renseigner'),
(173, 133, NULL, 'A renseigner'),
(174, 134, NULL, 'A renseigner'),
(175, 135, NULL, 'A renseigner'),
(176, 136, NULL, 'A renseigner'),
(177, 137, NULL, 'A renseigner'),
(178, 138, NULL, 'A renseigner'),
(179, 139, NULL, 'A renseigner'),
(180, 140, NULL, 'A renseigner'),
(181, 141, NULL, 'A renseigner'),
(182, 142, NULL, 'A renseigner'),
(183, 143, NULL, 'A renseigner'),
(184, 144, NULL, 'A renseigner'),
(185, 145, NULL, 'A renseigner'),
(186, 146, NULL, 'A renseigner'),
(187, 147, NULL, 'A renseigner'),
(188, 148, NULL, 'A renseigner'),
(189, 149, NULL, 'A renseigner'),
(190, 150, NULL, 'A renseigner'),
(191, 151, NULL, 'A renseigner'),
(195, 155, NULL, 'A renseigner'),
(196, 156, NULL, 'A renseigner'),
(197, 157, NULL, 'A renseigner'),
(198, 158, NULL, 'A renseigner'),
(199, 159, NULL, 'A renseigner'),
(200, 160, NULL, 'A renseigner');

-- --------------------------------------------------------

--
-- Structure de la table `tab_inscription`
--

DROP TABLE IF EXISTS `tab_inscription`;
CREATE TABLE IF NOT EXISTS `tab_inscription` (
  `inscription_id` int(11) NOT NULL AUTO_INCREMENT,
  `inscription_classe_id` int(11) NOT NULL,
  `inscription_personne_id` int(11) NOT NULL,
  PRIMARY KEY (`inscription_id`),
  KEY `inscription_classe_id` (`inscription_classe_id`),
  KEY `inscription_personne_id` (`inscription_personne_id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_inscription`
--

INSERT INTO `tab_inscription` (`inscription_id`, `inscription_classe_id`, `inscription_personne_id`) VALUES
(77, 3, 144),
(78, 3, 145),
(79, 3, 146),
(80, 4, 147),
(81, 4, 148),
(82, 5, 149),
(83, 5, 150),
(84, 6, 151),
(85, 6, 152),
(86, 6, 153),
(87, 7, 154),
(88, 8, 155),
(89, 9, 156),
(90, 10, 157),
(91, 10, 158),
(92, 11, 159),
(93, 12, 160),
(94, 13, 161),
(95, 14, 162),
(96, 15, 163),
(97, 9, 164),
(98, 9, 165),
(99, 10, 166),
(100, 9, 167),
(101, 8, 168),
(102, 25, 169),
(103, 24, 170),
(104, 24, 171),
(105, 23, 172),
(106, 23, 173),
(107, 22, 174),
(108, 21, 175),
(109, 20, 176),
(110, 18, 177),
(111, 16, 178),
(113, 26, 182),
(114, 27, 184);

-- --------------------------------------------------------

--
-- Structure de la table `tab_niveau`
--

DROP TABLE IF EXISTS `tab_niveau`;
CREATE TABLE IF NOT EXISTS `tab_niveau` (
  `niveau_id` int(11) NOT NULL AUTO_INCREMENT,
  `niveau_nom` int(11) NOT NULL,
  PRIMARY KEY (`niveau_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_niveau`
--

INSERT INTO `tab_niveau` (`niveau_id`, `niveau_nom`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 0);

-- --------------------------------------------------------

--
-- Structure de la table `tab_personne`
--

DROP TABLE IF EXISTS `tab_personne`;
CREATE TABLE IF NOT EXISTS `tab_personne` (
  `personne_id` int(11) NOT NULL AUTO_INCREMENT,
  `personne_nom` varchar(255) NOT NULL,
  `personne_prenom` varchar(255) NOT NULL,
  `personne_type` varchar(255) NOT NULL,
  PRIMARY KEY (`personne_id`)
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_personne`
--

INSERT INTO `tab_personne` (`personne_id`, `personne_nom`, `personne_prenom`, `personne_type`) VALUES
(140, 'Segado', 'Jean Pierre', 'prof'),
(141, 'Le Cor', 'Luc', 'prof'),
(142, 'Des Neiges', 'Marie', 'prof'),
(144, 'Vidal', 'Antoine', 'etu'),
(145, 'Xavier', 'Koczan', 'etu'),
(146, 'Le Du', 'Laure', 'etu'),
(147, 'Benistand', 'Sylvain', 'etu'),
(148, 'Lancman', 'Nathan', 'etu'),
(149, 'Steinburger', 'Lucie', 'etu'),
(150, 'Le Loher', 'Guillaume', 'etu'),
(151, 'Prouvost', 'Jean', 'etu'),
(152, 'Meunier', 'Helene', 'etu'),
(153, 'Bousiquier', 'Louis', 'etu'),
(154, 'Rathery', 'Amandine', 'etu'),
(155, 'Levi', 'Lea', 'etu'),
(156, 'Mongault', 'Quentin', 'etu'),
(157, 'Mulliez', 'Quentin', 'etu'),
(158, 'Lefort', 'Charles', 'etu'),
(159, 'Dessouki', 'Lucas', 'etu'),
(160, 'Do Barreiro', 'Stan', 'etu'),
(161, 'Mesnard', 'Vincent', 'etu'),
(162, 'Sartoris', 'Louis', 'etu'),
(163, 'Le Dain', 'Vincent', 'etu'),
(164, 'Laurent', 'Thomas', 'etu'),
(165, 'Bailey', 'Jeremy', 'etu'),
(166, 'Bouvier', 'Lucie', 'etu'),
(167, 'Tordjman', 'Ilana', 'etu'),
(168, 'Kyle', 'Krys', 'etu'),
(169, 'Rendler', 'Elizabeth', 'etu'),
(170, 'Coudray', 'Fabienne', 'etu'),
(171, 'Mouhali', 'Wallid', 'etu'),
(172, 'Chaari', 'Yannis', 'etu'),
(173, 'Crambes', 'Catherine', 'etu'),
(174, 'Eiffel', 'Thomas', 'etu'),
(175, 'Marie', 'Sebastien', 'etu'),
(176, 'Inocencio', 'Valentin', 'etu'),
(177, 'Irlinger', 'Margot', 'etu'),
(178, 'Mace', 'Valentine', 'etu'),
(181, 'Naulin', 'David', 'prof'),
(182, 'Mikael', 'John', 'etu'),
(183, 'Maoni', 'Brice', 'prof'),
(184, 'Lapage', 'Pierre', 'etu');

-- --------------------------------------------------------

--
-- Structure de la table `tab_trimestre`
--

DROP TABLE IF EXISTS `tab_trimestre`;
CREATE TABLE IF NOT EXISTS `tab_trimestre` (
  `trimestre_id` int(11) NOT NULL AUTO_INCREMENT,
  `trimestre_numero` int(11) NOT NULL,
  `trimestre_debut` date NOT NULL,
  `trimestre_fin` date NOT NULL,
  `trimestre_annescolaire_id` int(11) NOT NULL,
  PRIMARY KEY (`trimestre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `tab_trimestre`
--

INSERT INTO `tab_trimestre` (`trimestre_id`, `trimestre_numero`, `trimestre_debut`, `trimestre_fin`, `trimestre_annescolaire_id`) VALUES
(1, 1, '2019-01-01', '2019-02-28', 2019),
(2, 2, '2019-03-01', '2019-04-30', 2019),
(3, 3, '2019-05-01', '2019-06-30', 2019);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tab_classe`
--
ALTER TABLE `tab_classe`
  ADD CONSTRAINT `tab_classe_ibfk_3` FOREIGN KEY (`classe_niveau_id`) REFERENCES `tab_niveau` (`niveau_id`);

--
-- Contraintes pour la table `tab_detailbulletin`
--
ALTER TABLE `tab_detailbulletin`
  ADD CONSTRAINT `tab_detailbulletin_ibfk_1` FOREIGN KEY (`detailbulletin_bulletin_id`) REFERENCES `tab_bulletin` (`bulletin_id`);

--
-- Contraintes pour la table `tab_enseignement`
--
ALTER TABLE `tab_enseignement`
  ADD CONSTRAINT `tab_enseignement_ibfk_3` FOREIGN KEY (`enseignement_personne_id`) REFERENCES `tab_personne` (`personne_id`),
  ADD CONSTRAINT `tab_enseignement_ibfk_4` FOREIGN KEY (`enseignement_discipline_id`) REFERENCES `tab_discipline` (`discipline_id`);

--
-- Contraintes pour la table `tab_inscription`
--
ALTER TABLE `tab_inscription`
  ADD CONSTRAINT `tab_inscription_ibfk_1` FOREIGN KEY (`inscription_classe_id`) REFERENCES `tab_classe` (`classe_id`),
  ADD CONSTRAINT `tab_inscription_ibfk_2` FOREIGN KEY (`inscription_personne_id`) REFERENCES `tab_personne` (`personne_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
