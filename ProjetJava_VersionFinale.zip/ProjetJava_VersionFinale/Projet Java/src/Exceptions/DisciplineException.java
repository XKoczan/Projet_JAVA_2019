/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 * Classe DisciplineException
 * @author xavie
 */
public class DisciplineException extends Exception{ 
    /**
     * Constructeur de la classe
     * @param message 
     */
    public DisciplineException(String message){
        super(message);
    }
}
