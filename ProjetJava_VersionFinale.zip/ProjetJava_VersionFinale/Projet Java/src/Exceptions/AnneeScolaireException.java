/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

/**
 * Classe AnneeScolaireException
 * @author xavie
 */
public class AnneeScolaireException extends Exception{
    /**
     * Constructeur de la classe
     * @param message 
     */
    public AnneeScolaireException(String message){
        super(message);
    }
    
}
