/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

import Vue.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

/**
 * Class Connection
 *
 * @author xavie
 */
public class Connect {

    

    /**
     * Fenetre de connection à la base de donnée
     */
    public void fenetre_conn(){
        // On crée une JFrame
        JFrame connecte = new JFrame("Connection a l'application de gestion");
        JButton button_connect = new JButton("Connexion");
        JLabel l1 = new JLabel("Utilisateur");
        JLabel l2 = new JLabel("Mot de passe");
        JLabel l3 = new JLabel("Choix du serveur");
        JTextField t1 = new JTextField("root");
        JTextField t2 = new JTextField("");
        JTextField t3 = new JTextField("gestion_ecole");

        connecte.setLayout(new GridLayout(8, 1));
        connecte.setSize(500, 500);
        connecte.setLocationRelativeTo(null);
        connecte.setVisible(true);
        connecte.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // On créera un ActionListener 
        button_connect.addActionListener((ActionEvent e) -> {

            // On affiche une trace
            System.out.println("On rentre dans le boutton connection");

            // On renseigne les informations saisies
            String url = "jdbc:mysql://localhost/";
            String dbName = t3.getText();
            String driver = "com.mysql.jdbc.Driver";
            String userName = t1.getText();
            String password = t2.getText();
            System.out.println("1");
            // On essaie de se connecter 
            try {
                System.out.println("1");
                Class.forName(driver);
                Connection conn = DriverManager.getConnection(url + dbName, userName, password);
                System.out.println("1");
                if(conn==null){
                    System.out.println("AH");
                }else{
                    System.out.println(conn);
                }
                // Si la connection est ok 
                // On lance une interface graphique
                InterfaceGraphique IG = new InterfaceGraphique(conn);
                              
                connecte.dispose();

            } catch (ClassNotFoundException | SQLException ezs) {
                // sinon on affiche une fenetre d'erreur
                System.out.println("bon");
                Vue.Error err = new Vue.Error("Compte Sql introuvable");

            }
        });

        // On ajoute les boutons
        connecte.add(l1);
        connecte.add(t1);
        connecte.add(l2);
        connecte.add(t2);
        connecte.add(l3);
        connecte.add(t3);
        connecte.add(button_connect);

    }
}
