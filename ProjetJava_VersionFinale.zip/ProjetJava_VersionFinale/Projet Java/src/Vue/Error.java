/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import javax.swing.*;

/**
 *  Classe error
 * @author xavie
 */
public class Error {
    //Attributs
    private JFrame frame= new JFrame();
    /**
     * Constructeur par defaut
     */
    
    Error(){};
    /**
     * Constructeur de la classe avec un message à afficher
     * @param message 
     */
    public Error(String message){
        frame = new JFrame("Error");
        JLabel lab = new JLabel(message);
        frame.setSize(300, 100);
        frame.setLocationRelativeTo(null);
        frame.add(lab);
        frame.setVisible(true);
    }

    /**
     * Getter de la frame
     * @return 
     */
    public JFrame getFrame() {
        return frame;
    }
    
}
