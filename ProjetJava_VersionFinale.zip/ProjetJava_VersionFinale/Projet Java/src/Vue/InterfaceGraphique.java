
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vue;

import Exceptions.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.io.IOException;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import projet.java.*;

/**
 *
 * @author xavie
 */
/**
 * Classe InterfaceGraphique
 *
 * @author xavie
 */
public final class InterfaceGraphique {

    //Attributs
    JFrame frame_accueil = new JFrame("Accueil");
    JFrame interface_eleve = new JFrame("InterfaceEleve");
    Fenetre f = new Fenetre();
    Fenetre f2 = new Fenetre();
    Connection conn = null;

    Error err = new Error();
    int trimestre = 0;
    JButton button_eleve = new JButton("Fiche Eleve");

    JFrame interface_professeur;
    JButton button_professeur = new JButton("Fiche Professeur");

    JFrame interface_discipline;
    JButton button_discipline = new JButton("Fiche Discipline");
    JMenu menu = new JMenu("");

    JFrame interface_classe;
    JButton button_classe = new JButton("Fiche Classe");

    String matiere = "";
    Note note = new Note();
    private int status;

    JButton reporting = new JButton("Reporting");

    JTable table = new JTable();
    JTable table2 = new JTable();
    Classe classe = null;

    /**
     * Constructeur
     *
     * @param conn
     */
    public InterfaceGraphique(Connection conn) {
        this.conn = conn;
        // On crée la fenetre principale

        creer_fenetre(frame_accueil, 500, 500);
        // On lui associe une GridLayout 
        frame_accueil.setLayout(new GridLayout(5, 1));
        // On créera un ActionListener pour le bouton élève 
        button_eleve.addActionListener((ActionEvent e) -> {
            // On affiche une trace
            System.out.println("On rentre dans le bouton Eleve");

            // On crée la fenetre 
            fenetre_eleve();

        });
        button_professeur.addActionListener((ActionEvent e) -> {
            // On affiche une trace
            System.out.println("On rentre dans le bouton Professeur");

            // On crée la fenetre 
            fenetre_professeur();

        });
        button_discipline.addActionListener((ActionEvent e) -> {
            // On affiche une trace
            System.out.println("On rentre dans le bouton Discipline");

            // On crée la fenetre 
            fenetre_discipline();

        });

        button_classe.addActionListener((ActionEvent e) -> {
            // On affiche une trace
            System.out.println("On rentre dans le bouton Classe");

            // On crée la fenetre 
            fenetre_classe();

        });

        reporting.addActionListener((ActionEvent e) -> {
            // On lance la fenetre de reporting
            try {
                FenetreStatAccueil fsa = new FenetreStatAccueil(conn);
            } catch (IOException ex) {
                // On lance une fenetre d'erreur
                err.getFrame().dispose();
                err = new Error("Erreur lors du chargement");
            }

        });
        // On set quoi faire une fois qu'on quitte la fenetre
        frame_accueil.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // On ajoute le bouton
        frame_accueil.add(button_eleve);
        frame_accueil.add(button_professeur);
        frame_accueil.add(button_discipline);
        frame_accueil.add(button_classe);
        frame_accueil.add(reporting);

    }

    /**
     * Constructeur par defaut
     */
    public InterfaceGraphique() {
    }
    /**
     * Création de fenetre
     *
     * @param f
     * @param x
     * @param y
     */
    public final void creer_fenetre(JFrame f, int x, int y) {

        // On set la taille de la fenetre avec les valeurs en parametre
        f.setSize(x, y);
        // On centre a fenetre
        f.setLocationRelativeTo(null);
        // On l'affiche 
        f.setVisible(true);

    }

    /**
     * On lance une fentre eleve
     */
    public void fenetre_eleve() {
        // On cree une dao eleve
        DAO_Eleve dao_eleve = new DAO_Eleve(conn, classe);
          classe =null ;
        // On adapte la fenetre
        interface_eleve = new JFrame("InterfaceEleve");
        creer_fenetre(interface_eleve, 500, 200);
        interface_eleve.setLayout(new GridLayout(1, 2));
        // On lui crée une architecture
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));
        table = new JTable(dao_eleve.getCollection_eleve().size() + 1, 4);

        table.setValueAt("ID", 0, 0);
        table.setValueAt("Nom", 0, 1);
        table.setValueAt("Prenom", 0, 2);
        table.setValueAt("Type", 0, 3);

        int ligne = 1;
        // On rentre les valeurs reçues
        for (Personne e : dao_eleve.getCollection_eleve()) {
            System.out.println(e.getId() + ":" + e.getNom() + ":" + e.getPrenom() + ":" + e.getType());
            table.setValueAt(e.getId(), ligne, 0);
            table.setValueAt(e.getNom(), ligne, 1);
            table.setValueAt(e.getPrenom(), ligne, 2);
            table.setValueAt(e.getType(), ligne, 3);
            ligne++;
        }
        //Boutons
        JButton ajouter = new JButton("Ajouter un eleve");
        JButton supprimer = new JButton("Supprimer");
        JButton modifier = new JButton("Sauvegarder les changements");
        JButton consulter = new JButton("Consulter le bulletin de l'élève");
        JButton rechercher = new JButton("Rechercher un etudiant");
        // ActionsListeners
        ajouter.addActionListener((ActionEvent e) -> {
            //On lance une nouvelle fenetre dans laquelle one renseigne les informations
            f.getFrame().dispose();
            f = new Fenetre("AjoutEleve");
            JTextField t1 = new JTextField("Nom", 10);
            JTextField t2 = new JTextField("Prenom", 10);
            JLabel lab = new JLabel("Classe");
            JComboBox t3 = new JComboBox();
            dao_eleve.creer_combobox(t3);
            JButton conf = new JButton("Confirmer");
            // Lorsqu'on confirme
            conf.addActionListener((ActionEvent evt) -> {
                // On affiche une trace
                System.out.println(parseInt((String) t3.getSelectedItem()));
                try {
                    // On recherche si l'élément existe eventuellement on lance une fenetre d'erreur
                    dao_eleve.rechercher_eleve(new Eleve(dao_eleve.getCollection_eleve().size(), t1.getText(), t2.getText()));
                    err.getFrame().dispose();
                    err = new Error("L'element existe déjà");
                } catch (NonExistingElement aee) {
                    // s'il n'existe pas on crée l'éleve
                    dao_eleve.creer(new Eleve(dao_eleve.getCollection_eleve().size(), t1.getText(), t2.getText()), parseInt((String) t3.getSelectedItem()));
                    // On relance la page
                    f.getFrame().dispose();
                    
                    interface_eleve.dispose();
                    fenetre_eleve();
                }

            });
            // On ajoute les éléments à la fenetre
            f.getPanel().setLayout(new BoxLayout(f.getPanel(), BoxLayout.Y_AXIS));
            f.getPanel().add(t1);
            f.getPanel().add(t2);
            JPanel panel2 = new JPanel();
            panel2.add(lab);
            panel2.add(t3);
            f.getPanel().add(panel2);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);
          

        });
        // Supprimer
        supprimer.addActionListener((ActionEvent e) -> {

            try {
                // On essaie de supprimer
                dao_eleve.supprimer(dao_eleve.getCollection_eleve().get(table.getSelectedRow() - 1));
                // On relance la page
                interface_eleve.dispose();
                fenetre_eleve();
            } catch (ArrayIndexOutOfBoundsException ai) {
                // Sinon on lance une fenetre d'erreur
                err.getFrame().dispose();
                err = new Error("Veuillez sélectrionner un élément dans le tableau ");
            }

        });
        // on crée un model pour repérer les changements de la table
        table.getSelectionModel().addListSelectionListener((ListSelectionEvent e1) -> {
            try {

                System.out.println(table.getValueAt(table.getSelectedRow(), table.getSelectedColumn()).toString());
                table.setValueAt(table.getValueAt(table.getSelectedRow(), table.getSelectedColumn()).toString(), table.getSelectedRow(), table.getSelectedColumn());
            } catch (Exception e) {
            }

        });
        // Si on clique sur modifier
        modifier.addActionListener((ActionEvent evt) -> {
            // On modifie ligne par ligne
            int size = dao_eleve.getCollection_eleve().size() + 1;
            dao_eleve.getCollection_eleve().clear();
            System.out.println(dao_eleve.getCollection_eleve().size());
            for (int i = 1; i < size; i++) {
                dao_eleve.modifier(new Eleve((int) table.getValueAt(i, 0), (String) table.getValueAt(i, 1), (String) table.getValueAt(i, 2)));
            }
            // On relance la fenetre
            interface_eleve.dispose();
            fenetre_eleve();
        });
        // Si on clique sur consulter
        consulter.addActionListener((ActionEvent evt) -> {
            // On affiche le trimestre
            System.out.println(trimestre);
            try {
                // Si le trismestre est renseigné
                if (trimestre != 0) {
                    // On affiche le bulletin
                    Bulletin bulletin = dao_eleve.consulter_bulletin(dao_eleve.getCollection_eleve().get(table.getSelectedRow() - 1), trimestre);
                    afficher_bulletin(bulletin, dao_eleve);
                    // on ferme la fenetre
                    interface_eleve.dispose();
                } else {
                    // On affiche une erreur sinon
                    err.getFrame().dispose();
                    err = new Error("Veuillez selectrionner un trismestre");
                }

            } catch (Exception e) {
                // Si on n'a pas selectionnné de ligne on affiche un message d'erreur
                System.out.println("element non renseigné");
                err.getFrame().dispose();
                err = new Error("Veuillez selectrionner un element dans le tableau");
            }

        });
        // si on clique sur le bouton recherche
        rechercher.addActionListener((ActionEvent evt) -> {

            // On lance une fenetre de recharcher
            f.getFrame().dispose();
            f = new Fenetre("RechercherEleve");
            JTextField t1 = new JTextField("Nom", 10);
            JTextField t2 = new JTextField("Prenom", 10);

            JButton conf = new JButton("Confirmer");
            conf.addActionListener((ActionEvent evt2) -> {
                boolean verif = false;
                // on recherche dans la collection

                for (Eleve e : dao_eleve.getCollection_eleve()) {

                    // on affiche l'element
                    if (e.getNom().equals(t1.getText()) && e.getPrenom().equals(t2.getText())) {
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.setRowCount(2);
                        System.out.println("TROUVE");

                        table.setValueAt("ID", 0, 0);
                        table.setValueAt("Nom", 0, 1);
                        table.setValueAt("Prenom", 0, 2);
                        table.setValueAt("Type", 0, 3);

                        table.setValueAt(e.getId(), 1, 0);
                        table.setValueAt(e.getNom(), 1, 1);
                        table.setValueAt(e.getPrenom(), 1, 2);
                        table.setValueAt(e.getType(), 1, 3);
                        verif = true;
                        break;
                    } else {
                        verif = false;

                    }
                }
                if (!verif) {

                    err.getFrame().dispose();
                    err = new Error("La recherche n'a donné aucun résultat");
                }
                f.getFrame().dispose();

            });

            f.getPanel().setLayout(new BoxLayout(f.getPanel(), BoxLayout.Y_AXIS));
            f.getPanel().add(t1);
            f.getPanel().add(t2);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);

        });
// On affiche chaque element dans la frame
        panel.add(ajouter);
        panel.add(supprimer);
        panel.add(modifier);
        panel.add(consulter);
        panel.add(rechercher);
        interface_eleve.add(table);
        interface_eleve.add(panel);
        jmenuB();
    }

    /**
     * Fenetre d'affichage des professeurs avec les options
     */
    public void fenetre_professeur() {

        DAO_Professeur dao_professeur = new DAO_Professeur(conn);
        interface_professeur = new JFrame("InterfaceProfesseur");
        creer_fenetre(interface_professeur, 500, 200);
        interface_professeur.setVisible(true);
        interface_professeur.setLayout(new GridLayout(1, 2));

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));
        table = new JTable(dao_professeur.getCollection_professeur().size() + 1, 4);

        table.setValueAt("ID", 0, 0);
        table.setValueAt("Nom", 0, 1);
        table.setValueAt("Prenom", 0, 2);
        table.setValueAt("Type", 0, 3);

        int ligne = 1;

        for (Professeur e : dao_professeur.getCollection_professeur()) {
            System.out.println(e.getId() + ":" + e.getNom() + ":" + e.getPrenom() + ":" + e.getType());
            table.setValueAt(e.getId(), ligne, 0);
            table.setValueAt(e.getNom(), ligne, 1);
            table.setValueAt(e.getPrenom(), ligne, 2);
            table.setValueAt(e.getType(), ligne, 3);
            ligne++;
        }

        JButton ajouter = new JButton("Ajouter un professeur");
        JButton supprimer = new JButton("Supprimer");
        JButton modifier = new JButton("Sauvegarder les changements");
        JButton rechercher = new JButton("Rechercher une professeur");
        ajouter.addActionListener((ActionEvent e) -> {

            f = new Fenetre("AjoutProfesseur");

            JTextField t1 = new JTextField("Nom", 10);
            JTextField t2 = new JTextField("Prenom", 10);
            JTextField t3 = new JTextField("Classe", 10);
            JTextField t4 = new JTextField("Discipline", 10);

            JButton conf = new JButton("Confirmer");
            conf.addActionListener((ActionEvent evt) -> {
                try {

                    System.out.println(parseInt(t3.getText()));
                    System.out.println(parseInt(t4.getText()));
                    dao_professeur.rechercher_professeur(new Professeur(dao_professeur.getCollection_professeur().size(), t1.getText(), t2.getText()));
                    err.getFrame().dispose();
                    err = new Error("L'element existe déjà");
                } catch (NonExistingElement aee) {

                    try {
                        dao_professeur.creer(new Professeur(dao_professeur.getCollection_professeur().size(), t1.getText(), t2.getText()), parseInt(t3.getText()), parseInt(t4.getText()));

                        f.getFrame().dispose();
                        interface_professeur.dispose();
                        fenetre_professeur();
                    } catch (DisciplineException nfe) {
                        System.out.println("Error");
                        err.getFrame().dispose();
                        err = new Error("Discipline : l'id renseigné n'existe pas");
                    } catch (ClasseException cfe) {
                        System.out.println("Error");
                        err.getFrame().dispose();
                        err = new Error("Classe : l'id renseigné n'existe pas");
                    } catch (SQLException ex) {
                        err.getFrame().dispose();
                        err = new Error("SQL : Erreur lors de l'execution");
                    }
                } catch (NumberFormatException nfe) {
                    System.out.println("Error");
                    err.getFrame().dispose();
                    err = new Error(" Un id renseigné n'existe pas");
                }

            });

            f.getPanel().add(t1);
            f.getPanel().add(t2);
            f.getPanel().add(t3);
            f.getPanel().add(t4);
            f.getFrame().setSize(275, 300);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);

        });

        supprimer.addActionListener((ActionEvent e) -> {

            try {

                dao_professeur.supprimer(dao_professeur.getCollection_professeur().get(table.getSelectedRow() - 1));
                interface_professeur.dispose();
                fenetre_professeur();
            } catch (ArrayIndexOutOfBoundsException ai) {
                err.getFrame().dispose();
                err = new Error("Veuillez sélectrionner un élément dans le tableau ");
            }

        });

        table.getSelectionModel().addListSelectionListener((ListSelectionEvent e1) -> {
            try {

                System.out.println(table.getValueAt(table.getSelectedRow(), table.getSelectedColumn()).toString());
                table.setValueAt(table.getValueAt(table.getSelectedRow(), table.getSelectedColumn()).toString(), table.getSelectedRow(), table.getSelectedColumn());
            } catch (Exception e) {
            }
        });

        modifier.addActionListener((ActionEvent evt) -> {
            int size = dao_professeur.getCollection_professeur().size() + 1;
            dao_professeur.getCollection_professeur().clear();
            System.out.println(dao_professeur.getCollection_professeur().size());
            for (int i = 1; i < size; i++) {
                dao_professeur.modifier(new Professeur((int) table.getValueAt(i, 0), (String) table.getValueAt(i, 1), (String) table.getValueAt(i, 2)));
            }
            interface_professeur.dispose();
            fenetre_professeur();
        });

        rechercher.addActionListener((ActionEvent evt) -> {

            f.getFrame().dispose();
            f = new Fenetre("RechercherProfesseur");
            JTextField t1 = new JTextField("Nom", 10);
            JTextField t2 = new JTextField("Prenom", 10);

            JButton conf = new JButton("Confirmer");
            conf.addActionListener((ActionEvent evt2) -> {
                boolean verif=false;
                for (Professeur e : dao_professeur.getCollection_professeur()) {
                    if (e.getNom().equals(t1.getText()) && e.getPrenom().equals(t2.getText())) {
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.setRowCount(2);
                        System.out.println("TROUVE");

                        table.setValueAt("ID", 0, 0);
                        table.setValueAt("Nom", 0, 1);
                        table.setValueAt("Prenom", 0, 2);
                        table.setValueAt("Type", 0, 3);

                        table.setValueAt(e.getId(), 1, 0);
                        table.setValueAt(e.getNom(), 1, 1);
                        table.setValueAt(e.getPrenom(), 1, 2);
                        table.setValueAt(e.getType(), 1, 3);
                         verif = true;
                        break;
                    } else {
                        verif = false;

                    }
                }
                if (!verif) {

                    err.getFrame().dispose();
                    err = new Error("La recherche n'a donné aucun résultat");
                }
                
                f.getFrame().dispose();

            });
            f.getPanel().setLayout(new BoxLayout(f.getPanel(), BoxLayout.Y_AXIS));
            f.getPanel().add(t1);
            f.getPanel().add(t2);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);

        });

        panel.add(ajouter);
        panel.add(supprimer);
        panel.add(modifier);
        panel.add(rechercher);
        interface_professeur.add(table);
        interface_professeur.add(panel);
    }

    /**
     * Fenetre d'affichage des discplines avec les optons associées
     */
    public void fenetre_discipline() {

        DAO_Discipline dao_discipline = new DAO_Discipline(conn);
        interface_discipline = new JFrame("InterfaceDiscipline");
        creer_fenetre(interface_discipline, 500, 200);
        interface_discipline.setLayout(new GridLayout(1, 2));

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));
        JTable table3 = new JTable(dao_discipline.getCollection_discipline().size() + 1, 2);

        table3.setValueAt("ID", 0, 0);
        table3.setValueAt("Nom", 0, 1);

        int ligne = 1;

        for (Discipline e : dao_discipline.getCollection_discipline()) {
            System.out.println(e.getId() + ":" + e.getNom());
            table3.setValueAt(e.getId(), ligne, 0);
            table3.setValueAt(e.getNom(), ligne, 1);
            ligne++;
        }

        JButton ajouter = new JButton("Ajouter une discipline");
        JButton supprimer = new JButton("Supprimer");
        JButton modifier = new JButton("Sauvegarder les changements");
        JButton rechercher = new JButton("Rechercher une discipline");
        ajouter.addActionListener((ActionEvent e) -> {

            f = new Fenetre("AjoutDiscipline");
            JTextField t2 = new JTextField("Matiere", 10);
            JButton conf = new JButton("Confirmer");
            conf.addActionListener((ActionEvent evt) -> {
//                    System.out.println(parseInt((String) t2.getText()));
                try {
                    dao_discipline.rechercher_discipline(new Discipline(t2.getText()));
                    err = new Error("L'element existe déjà");
                } catch (NonExistingElement aee) {

                    dao_discipline.creer(new Discipline(t2.getText()), 0);

                    f.getFrame().dispose();
                    interface_discipline.dispose();
                    fenetre_discipline();
                }

            });
            f.getPanel().add(t2);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);

        });

        supprimer.addActionListener((ActionEvent e) -> {

            try {

                dao_discipline.supprimer(dao_discipline.getCollection_discipline().get(table3.getSelectedRow() - 1));
                interface_discipline.dispose();
                fenetre_discipline();
            } catch (ArrayIndexOutOfBoundsException ai) {
                err.getFrame().dispose();
                err = new Error("Veuillez sélectrionner un élément dans le tableau ");
            }

        });

        table3.getSelectionModel().addListSelectionListener((ListSelectionEvent e1) -> {
            try {
                System.out.println(table3.getValueAt(table3.getSelectedRow(), table3.getSelectedColumn()).toString());
                table3.setValueAt(table3.getValueAt(table3.getSelectedRow(), table3.getSelectedColumn()).toString(), table3.getSelectedRow(), table3.getSelectedColumn());

            } catch (Exception e) {
            }
        });

        modifier.addActionListener((ActionEvent evt) -> {
            System.out.println(dao_discipline.getCollection_discipline().size());
            int size = dao_discipline.getCollection_discipline().size();
            dao_discipline.getCollection_discipline().clear();
            System.out.println("ONMODIFIE");
            System.out.println(dao_discipline.getCollection_discipline().size());
            for (int i = 1; i < size + 1; i++) {

                dao_discipline.modifier(new Discipline((int) table3.getValueAt(i, 0), (String) table3.getValueAt(i, 1)));
            }
            interface_discipline.dispose();
            fenetre_discipline();
        });

        rechercher.addActionListener((ActionEvent evt) -> {

            f.getFrame().dispose();
            f = new Fenetre("RechercherEleve");
            JTextField t1 = new JTextField("Nom", 10);

            JButton conf = new JButton("Confirmer");
            conf.addActionListener((ActionEvent evt2) -> {
                boolean verif=false;
                for (Discipline e : dao_discipline.getCollection_discipline()) {
                    if (e.getNom().equals(t1.getText())) {

                        DefaultTableModel model = (DefaultTableModel) table3.getModel();
                        model.setRowCount(2);
                        System.out.println("TROUVE");

                        table3.setValueAt("ID", 0, 0);
                        table3.setValueAt("Nom", 0, 1);

                        table3.setValueAt(e.getId(), 1, 0);
                        table3.setValueAt(e.getNom(), 1, 1);
                            verif = true;
                        break;
                    } else {
                        verif = false;

                    }
                }
                if (!verif) {

                    err.getFrame().dispose();
                    err = new Error("La recherche n'a donné aucun résultat");
                }
                
                f.getFrame().dispose();

            });
            f.getPanel().setLayout(new BoxLayout(f.getPanel(), BoxLayout.Y_AXIS));
            f.getPanel().add(t1);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);

        });

        panel.add(ajouter);
        panel.add(supprimer);
        panel.add(modifier);
        panel.add(rechercher);
        interface_discipline.add(table3);
        interface_discipline.add(panel);
    }

    /**
     * Classe de création d'une JMenuBar
     */
    public void jmenuB() {
        JMenuBar mb = new JMenuBar();
        menu = new JMenu("Trimestre");
        JMenuItem mi = new JMenuItem("Trimestre1");
        mi.addActionListener((ActionEvent e) -> {
            menu.setText("Trimestre1");
            trimestre = 1;
        });
        JMenuItem mi2 = new JMenuItem("Trimestre2");
        mi2.addActionListener((ActionEvent e) -> {
            menu.setText("Trimestre2");
            trimestre = 2;
        });
        JMenuItem mi3 = new JMenuItem("Trimestre3");
        mi3.addActionListener((ActionEvent e) -> {
            menu.setText("Trimestre3");
            trimestre = 3;
        });
        mi.setBackground(Color.magenta.darker());
        mi2.setBackground(Color.yellow.darker());
        mi3.setBackground(Color.yellow.darker());

        menu.add(mi);
        menu.add(mi2);
        menu.add(mi3);

        mb.add(menu);

        interface_eleve.setJMenuBar(mb);
    }

    /**
     * Fenetre d'affichage bulletin
     *
     * @param bulletin
     * @param dao_eleve
     */
    private void afficher_bulletin(Bulletin bulletin, DAO_Eleve dao_eleve) {
        f2.getFrame().dispose();
        f2 = new Fenetre("Bulletin :" + bulletin.getEleve().getNom() + " " + bulletin.getEleve().getPrenom());
        f2.getFrame().setSize(400, 200);
        f2.getPanel().setLayout(new BoxLayout(f2.getPanel(), BoxLayout.PAGE_AXIS));
        JLabel lab2 = new JLabel("Eleve : " + bulletin.getEleve().getNom() + " " + bulletin.getEleve().getPrenom());
        JLabel lab = new JLabel("Appreciation : " + bulletin.getAppreciation());
        JButton detail = new JButton("Voir le détail trimestre :" + trimestre);
        detail.addActionListener((ActionEvent evt) -> {
            try {
                dao_eleve.details_bulletin(bulletin);
                afficher_details(bulletin, dao_eleve);
            } catch (SQLException ex) {
                err = new Error("Probleme d'affichage");
            }
        });
        f2.getPanel().add(lab2);
        f2.getPanel().add(lab);
        f2.getPanel().add(detail);
        f2.getFrame().add(f2.getPanel());

    }
    /**
     * Affichage du bulletin
     * @param bulletin
     * @param dao_eleve
     * @throws SQLException 
     */
    public void afficher_details(Bulletin bulletin, DAO_Eleve dao_eleve) throws SQLException {
        matiere = null;

        Fenetre f3 = new Fenetre("Bulletin :" + bulletin.getEleve().getNom() + " " + bulletin.getEleve().getPrenom());
        f3.getFrame().setSize(400, 200);
        f3.getFrame().setLayout(new GridLayout(1, 2));
        f3.getPanel().setLayout(new BoxLayout(f3.getPanel(), BoxLayout.PAGE_AXIS));

        for (DetailBulletin db : bulletin.getDetails_collection()) {
            for (Map.Entry<String, ArrayList<Note>> e : db.getBulletin_data().entrySet()) {

                int ligne = 0;
                System.out.println("SIZE:" + e.getValue().size());
                JPanel panel = new JPanel();
                panel.setLayout(new BorderLayout());
                JTable table3 = new JTable(1, 1);
                table2 = new JTable(e.getValue().size(), 2);
                table3.setValueAt(e.getKey(), 0, 0);
                panel.add(table3, BorderLayout.CENTER);

                table2.getSelectionModel().addListSelectionListener((ListSelectionEvent e1) -> {
                    table2.setValueAt(parseInt(table2.getValueAt(table2.getSelectedRow(), 0).toString()), table2.getSelectedRow(), 0);
                    table2.setValueAt(table2.getValueAt(table2.getSelectedRow(), 1).toString(), table2.getSelectedRow(), 1);
                    for (Note e2 : e.getValue()) {

                        System.out.println(table2.getSelectedRow());
                        if (table2.getSelectedRow() == e.getValue().indexOf(e2)) {
                            note = e2;
                        }
                    }

                });
                System.out.println(e.getKey());
                for (Note e2 : e.getValue()) {

                    table2.setValueAt(e2.getNote(), ligne, 0);
                    table2.setValueAt(e2.getAppreciation(), ligne, 1);
                    System.out.println(e2.getNote() + "|" + e2.getAppreciation());
                    System.out.println(table2.getSelectedRow());
                    if (table2.getSelectedRow() == e.getValue().indexOf(e2)) {
                        note = e2;
                    }
                    ligne++;
                }
                ligne = 0;

                panel.add(table2, BorderLayout.EAST);
                f3.getPanel().add(panel);

                table3.getSelectionModel().addListSelectionListener((ListSelectionEvent e1) -> {
                    System.out.println(table3.getValueAt(table3.getSelectedRow(), table3.getSelectedColumn()).toString());
                    matiere = table3.getValueAt(table3.getSelectedRow(), table3.getSelectedColumn()).toString();
                });
            }

        }
        JButton ajouter = new JButton("Ajouter une note");
        JButton supprimer = new JButton("Supprimer");
        JButton modifier = new JButton("Sauvegarder les changements");

        ajouter.addActionListener(
                (ActionEvent evt) -> {
                    f.getFrame().dispose();
                    f = new Fenetre("AjoutNote");
                    JTextField txt1 = new JTextField("Note");
                    JButton conf = new JButton("Confirmer");

                    conf.addActionListener((ActionEvent evt2) -> {
                        try {
                            if (matiere == null) {
                                throw new Exception();
                            }
                            System.out.println(parseInt(txt1.getText()));
                            dao_eleve.creer_note(bulletin, parseInt(txt1.getText()), matiere);

                            f3.getFrame().dispose();

                            dao_eleve.details_bulletin(bulletin);
                            afficher_details(bulletin, dao_eleve);

                        } catch (SQLException ex) {
                            err = new Error("Probleme d'affichage");
                        } catch (NumberFormatException nfe) {
                            err.getFrame().dispose();
                            err = new Error("Veuillez entrer une Note valide");
                        } catch (Exception ex) {
                            err.getFrame().dispose();
                            err = new Error("Veuillez selectionner une matiere");
                        }

                        f.getFrame().dispose();

                    });
                    f.getFrame().add(txt1);
                    f.getFrame().add(conf);

                }
        );

        supprimer.addActionListener(
                (ActionEvent evt) -> {

                    try {
                        dao_eleve.supprimer_note(note.getId());

                    } catch (SQLException ex) {
                        err = new Error("Probleme d'affichage");
                    }

                    f.getFrame().dispose();
                    f3.getFrame().dispose();
                    try {
                        dao_eleve.details_bulletin(bulletin);
                        f3.getFrame().dispose();
                        afficher_details(bulletin, dao_eleve);
                    } catch (SQLException ex) {
                        err = new Error("Probleme d'affichage");
                    }

                }
        );

        modifier.addActionListener((ActionEvent evt) -> {
            int ligne = 0;
            System.out.println("NOTE2:" + note.getId() + "|" + note.getNote() + "|" + note.getAppreciation());
            for (DetailBulletin db : bulletin.getDetails_collection()) {
                for (Map.Entry<String, ArrayList<Note>> e : db.getBulletin_data().entrySet()) {
                    for (Note e2 : e.getValue()) {

                        e2.setNote(parseInt(table2.getValueAt(ligne, 0).toString()));
                        e2.setAppreciation(table2.getValueAt(ligne, 1).toString());
                        System.out.println(e2.getNote() + "|" + e2.getAppreciation());
                        dao_eleve.modifier(e2);
                        ligne++;
                    }

                }
            }

            try {
                f3.getFrame().dispose();
                afficher_details(bulletin, dao_eleve);
            } catch (SQLException ex) {
                err = new Error("Probleme d'affichage");
            }
        }
        );

        JPanel panel2 = new JPanel();

        panel2.setLayout(
                new GridLayout(3, 1));
        panel2.add(ajouter);

        panel2.add(supprimer);

        panel2.add(modifier);

        f3.getFrame()
                .add(f3.getPanel());
        f3.getFrame()
                .add(panel2);

    }
    /**
     * Fenetre de classe + différentes interfaces
     */
    public void fenetre_classe() {
        DAO_Classe dao_classe = new DAO_Classe(conn);
        interface_classe = new JFrame("InterfaceClasse");
        creer_fenetre(interface_classe, 500, 200);
        interface_classe.setLayout(new GridLayout(1, 2));

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 1));
        table = new JTable(dao_classe.getCollection_classe().size() + 1, 4);

        table.setValueAt("ID", 0, 0);
        table.setValueAt("Nom", 0, 1);
        table.setValueAt("Niveau", 0, 2);
        table.setValueAt("Année Scolaire", 0, 3);
        int ligne = 1;

        for (Classe e : dao_classe.getCollection_classe()) {
            System.out.println(e.getId() + ":" + e.getNom());
            table.setValueAt(e.getId(), ligne, 0);
            table.setValueAt(e.getNom(), ligne, 1);
            table.setValueAt(e.getNiveau(), ligne, 2);
            table.setValueAt(e.getAnneescolaire_id(), ligne, 3);
            ligne++;
        }

        JButton ajouter = new JButton("Ajouter une classe");
        JButton supprimer = new JButton("Supprimer");
        JButton modifier = new JButton("Sauvegarder les changements");
        JButton rechercher = new JButton("Rechercher une classe");
        JButton eleves = new JButton("Afficher les eleves de la classe");

        ajouter.addActionListener((ActionEvent e) -> {

            f = new Fenetre("CreerClasse");
            JTextField t2 = new JTextField("Classe", 10);
            JTextField t3 = new JTextField("Niveau", 10);
            JTextField t4 = new JTextField("Annee scolaire", 10);
            JButton conf = new JButton("Confirmer");
            conf.addActionListener((ActionEvent evt) -> {
//                    System.out.println(parseInt((String) t2.getText()));
                try {
                    System.out.println(parseInt(t3.getText()));
                    System.out.println(parseInt(t4.getText()));
                    dao_classe.rechercher_classe(new Classe(t2.getText(), parseInt(t3.getText()), parseInt(t4.getText())));
                    err.getFrame().dispose();
                    err = new Error("L'element existe déjà");
                } catch (NonExistingElement aee) {

                    try {
                        dao_classe.creer(new Classe(t2.getText(), parseInt(t3.getText()), parseInt(t4.getText())));

                        f.getFrame().dispose();
                        interface_classe.dispose();
                        fenetre_classe();
                    } catch (AnneeScolaireException ase) {
                        err.getFrame().dispose();
                        err = new Error("Veuillez renseigner un id d'année valide");
                    } catch (SQLException ex) {
                        err.getFrame().dispose();
                        err = new Error("Probleme de creation");
                    }
                } catch (NumberFormatException nfe) {
                    err.getFrame().dispose();
                    err = new Error("Veuillez saisir une valeur d'id correcte");
                }

            });
            f.getPanel().add(t2);
            f.getPanel().add(t3);
            f.getPanel().add(t4);
            f.getFrame().add(f.getPanel());
            f.getFrame().add(conf);

        });

        supprimer.addActionListener((ActionEvent e) -> {

            try {

                dao_classe.supprimer(dao_classe.getCollection_classe().get(table.getSelectedRow() - 1));
                interface_classe.dispose();
                fenetre_classe();
            } catch (ArrayIndexOutOfBoundsException ai) {
                err.getFrame().dispose();
                err = new Error("Veuillez sélectrionner un élément dans le tableau ");
            }

        });

        table.getSelectionModel().addListSelectionListener((ListSelectionEvent e1) -> {

            try {

                System.out.println(table.getValueAt(table.getSelectedRow(), table.getSelectedColumn()).toString());
                table.setValueAt(table.getValueAt(table.getSelectedRow(), table.getSelectedColumn()).toString(), table.getSelectedRow(), table.getSelectedColumn());

            } catch (Exception e) {
            }
        });

        modifier.addActionListener((ActionEvent evt) -> {
            int size = dao_classe.getCollection_classe().size() + 1;
            dao_classe.getCollection_classe().clear();
            System.out.println(dao_classe.getCollection_classe().size());

            for (int i = 1; i < size; i++) {
                try {
                    dao_classe.modifier(new Classe((int) table.getValueAt(i, 0), (String) table.getValueAt(i, 1), (int) table.getValueAt(i, 2), (int) table.getValueAt(i, 3)));
                    interface_classe.dispose();
                    fenetre_classe();
                } catch (Exception exc) {
                    err.getFrame().dispose();
                    err = new Error("La valeur renseignée n'est pas valide");
                    break;
                }

            }

        });

        eleves.addActionListener((ActionEvent evt) -> {

            for (Classe c : dao_classe.getCollection_classe()) {
                if (c.getId() == parseInt(table.getValueAt(table.getSelectedRow(), 0).toString())) {
                    classe = c;
                }
            }
            interface_classe.dispose();
            fenetre_eleve();

        });
        panel.add(ajouter);
        panel.add(supprimer);
        panel.add(modifier);
        panel.add(rechercher);
        panel.add(eleves);
        interface_classe.add(table);
        interface_classe.add(panel);
    }

}
