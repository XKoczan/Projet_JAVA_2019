/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author Guillaume
 */
public class Discipline {

    int id;
    String nom;
/**
 * Constructeur par défault
 */
    Discipline() {
    }
/**
 * Constructeur surchargé 
 * @param nom 
 */
    public Discipline(String nom) {

        this.nom = nom;
    }
/**
 * Constructeur surchargé
 * @param id
 * @param nom 
 */
    public Discipline(int id, String nom) {
        this.id = id;
        this.nom = nom;
    }
/**
 * Getter de l'id
 * @return 
 */
    public int getId() {
        return id;
    }
/**
 * Getter de nom
 * @return 
 */
    public String getNom() {
        return nom;
    }
/**
 * Methode overrided toString
 * @return 
 */
    @Override
    public String toString() {
        return "ID:" + this.getId() + "|" + "NOM:" + this.getNom();
    }
}
