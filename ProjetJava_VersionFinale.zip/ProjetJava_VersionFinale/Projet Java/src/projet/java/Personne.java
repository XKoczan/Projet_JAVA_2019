/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author xavie
 */
public class Personne {
    private int id;
    private String nom;
    private String prenom;
    private String type;
    /**
     * Constructeur
     */
    public Personne(){};
    /**
     * Cosntructeur surchargé
     * @param id
     * @param nom
     * @param prenom
     * @param type 
     */
    public Personne(int id, String nom, String prenom, String type){
        this.id=id;
        this.nom=nom;
        this.prenom=prenom;
        this.type=type;
    }
/**
 * Getter D'id 
 * @return 
 */
    public int getId() {
        return id;
    }
/**
 * getter de nom
 * @return 
 */
    public String getNom() {
        return nom;
    }
/**
 * getter de prenom
 * @return 
 */
    public String getPrenom() {
        return prenom;
    }
/**
 * Getter de type
 * @return 
 */
    public String getType() {
        return type;
    }
/**
 * setting d'id
 * @param id 
 */
    public void setId(int id) {
        this.id = id;
    }
/**
 * setting de nom
 * @param nom 
 */
    public void setNom(String nom) {
        this.nom = nom;
    }
/**
 * setting de prenom
 * @param prenom 
 */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }
/**
 * Setting de type
 * @param type 
 */
    public void setType(String type) {
        this.type = type;
    }
    
    
}
