/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 *
 * @author vithu
 */
public class FenetreStatAccueil implements ActionListener {

    //Attributs
    //Fenetre d'Accueil (Fenetre principale)
    private final JFrame f = new JFrame("Accueil - Reporting");
    //Boutons pour les differentes fonctionnalités
    private final JButton b1 = new JButton("Part d'individus");
    private final JButton b2 = new JButton("Part d'étudiant dans chaque niveau");
    private final JButton b3 = new JButton("Part d'étudiant dans chaque classe");
    private final JButton b5 = new JButton("Retour page d'accueil");
    //Fenetres liés à chaque composant
    public FenetreStatIndividus fenStatIndividus;
    public FenetreStatNiveau fenStatNiveau;
    public FenetreStatClasse fenStatClasse;
    
    protected static Connection conn;
    /**
     * Constructeur
     */
    public FenetreStatAccueil(Connection conn) throws IOException {
        
        this.conn=conn;
        //Fenetre principale
        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //On centre la fenêtre sur l'écran
        f.setLocationRelativeTo(null);
        //on met une icone avec le titre de la JFrame
        Image iconee = ImageIO.read(new File("icon_stat.png"));
        f.setIconImage(iconee);
        //Grille de séparation en 10
        f.setLayout(new GridLayout(7, 0));

        //Titre centré en premiere ligne avec une icone de "portefeuille"
        JLabel titre = new JLabel("Reporting", SwingConstants.CENTER);
        //on fixe les paramètres de la police
        Font font = new Font(" TimesRoman ", Font.BOLD, 46);
        titre.setFont(font);
        //On affiche le titre en noir sur fond blanc
        titre.setOpaque(true); //pour afficher le fond, setOpaque doit être vrai
        titre.setBackground(Color.white);
        titre.setForeground(Color.black);
        //ajout du titre dans la fenetre
        f.getContentPane().add(titre);

        //Label vide pour espacer titre et boutons
        ImageIcon icone = new ImageIcon("icon_stat.png");
        JLabel icon = new JLabel("", icone, SwingConstants.CENTER);
        icon.setBackground(Color.white);
        icon.setOpaque(true);
        f.getContentPane().add(icon);

        //Label indiquant de faire un choix 
        JLabel choix = new JLabel("Que désirez-vous voir ?", SwingConstants.CENTER);
        Font fontChoix = new Font(" TimesRoman ", Font.PLAIN, 20);
        choix.setFont(fontChoix);
        choix.setForeground(Color.black);
        choix.setBackground(Color.white);
        choix.setOpaque(true);
        f.getContentPane().add(choix);

        //Ajout de 8 boutons pour les 8 fonctionnalités
        Font fontBoutton = new Font(" TimesRoman ", Font.PLAIN, 20);

        //on fixe les paramètres de la police du bouton 1
        b1.setFont(fontBoutton);
        b1.setForeground(Color.black);
        b1.setPreferredSize(new Dimension(500, 60));
        JPanel p1 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p1.add(b1);
        p1.setBackground(Color.white);
        //Listener si le bouton est cliqué 
        b1.addActionListener(this);

        //on fixe les paramètres de la police du bouton 2
        b2.setFont(fontBoutton);
        b2.setForeground(Color.black);
        b2.setPreferredSize(new Dimension(500, 60));
        JPanel p2 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p2.add(b2);
        p2.setBackground(Color.white);
        //Listener si le bouton est cliqué 
        b2.addActionListener(this);

        //on fixe les paramètres de la police du bouton 3
        b3.setFont(fontBoutton);
        b3.setForeground(Color.black);
        b3.setPreferredSize(new Dimension(500, 60));
        JPanel p3 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p3.add(b3);
        p3.setBackground(Color.white);
        //Listener si le bouton est cliqué 
        b3.addActionListener(this);

        //on fixe les paramètres de la police du bouton 7
        b5.setFont(new Font(" TimesRoman ", Font.BOLD, 20));
        b5.setForeground(Color.red);
        b5.setPreferredSize(new Dimension(500, 60));
        JPanel p5 = new JPanel(); //panel pour pouvoir dimensionner le bouton puisque le GridLayout dimensionne lui meme les composants
        p5.add(b5);
        p5.setBackground(Color.white);
        //Listener si le bouton est cliqué 
        b5.addActionListener(this);

        //Ajout des boutons centrés dans la fenetre
        f.getContentPane().add(p1, BorderLayout.CENTER);
        f.getContentPane().add(p2, BorderLayout.CENTER);
        f.getContentPane().add(p3, BorderLayout.CENTER);
        f.getContentPane().add(p5, BorderLayout.SOUTH);

        //fenetre Accueil rendue visible
        f.setVisible(true);

        //Les fenetres indiquees ci-dessous sont rendues invisibles
        if (fenStatIndividus != null) {
            fenStatIndividus.getFenetre().setVisible(false);

        }

    }

    

    //Méthodes
    @Override
    /**
     * actions spécifiques à effectuées suite à un "click" sur l'un des boutons
     */
   public void actionPerformed(ActionEvent e) {
        //f.setVisible(false);

        //Bouton "Part d'individus" cliqué
        if ((JButton) e.getSource() == b1) {
            try {
                fenStatIndividus = new FenetreStatIndividus(conn);
            } catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        } //Bouton "Part d'eleves dans un niveau" cliqué
        else if ((JButton) e.getSource() == b2) {
            try {
                fenStatNiveau = new FenetreStatNiveau(conn);
            } catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        } //Bouton "Part d'eleves dans une classe" cliqué
        else if ((JButton) e.getSource() == b3) {
            try {
                fenStatClasse = new FenetreStatClasse(conn);
            } catch (ClassNotFoundException ex) {
                System.out.println("ERREUR : Incident lors du chargement");
            } catch (SQLException ex) {
                System.out.println("ERREUR : Problème lors du 'click'");
            }
        } //Bouton "Retour page d'accueil" cliqué
        else if ((JButton) e.getSource() == b5) {
            f.setVisible(false);
        }
    }
}
