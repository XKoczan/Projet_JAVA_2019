/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import Exceptions.AnneeScolaireException;
import Exceptions.NonExistingElement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;

/**
 * Classe DAO_Classe
 * @author Guillaume
 */
public class DAO_Classe extends DAO<Classe> {

    private ArrayList<Classe> collection_classe = new ArrayList<>();
    /**
     * Constructeur par defaut
     */
    public DAO_Classe() {
        super();
        chargement();
    }
    /**
     * Constructeur surchargé
     * @param conn 
     */
    public DAO_Classe(Connection conn) {
        this.conn = conn;
        chargement();
    }
    /**
     * Methode de création d'element dans la BDD
     * @param obj
     * @throws SQLException
     * @throws AnneeScolaireException 
     */
    public void creer(Classe obj) throws SQLException, AnneeScolaireException {
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM tab_anneescolaire where anneescolaire_id = ?");
        stmt.setObject(1, obj.getAnneescolaire_id(), Types.INTEGER);
        ResultSet rs = stmt.executeQuery();
        
        if(!rs.next()){
            throw new AnneeScolaireException("");
        }
        
            stmt = conn.prepareStatement("insert into tab_classe(classe_nom,classe_niveau_id,classe_anneescolaire_id) values(?,?,?)");
            stmt.setObject(1, obj.getNom(), Types.VARCHAR);
            stmt.setObject(2, obj.getNiveau(), Types.INTEGER);
            stmt.setObject(3, obj.getAnneescolaire_id(), Types.INTEGER);
            stmt.executeUpdate();
        
    }
/**
 * Methode de suppression d'elements dans la bdd
 * @param obj 
 */
    @Override
    public void supprimer(Classe obj) {
        try {
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM tab_classe where classe_id = ?");
            stmt.setObject(1, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Probleme de suppression de la classe");
        }
    }
/**
 * Methode de modification d'elements dans la base de donnée
 * @param obj 
 */
    @Override
    public void modifier(Classe obj) {
        try {

            PreparedStatement stmt = conn.prepareStatement("Update tab_classe set classe_nom = ?,classe_niveau_id = ?  where classe_id = ? ");
            stmt.setObject(1, obj.getNom(), Types.VARCHAR);
            stmt.setObject(2, obj.getNiveau(), Types.INTEGER);
            stmt.setObject(3, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Probleme de modification de la classe");
        }
    }
/**
 * Methode de chargement
 */
    @Override
    public void chargement() {
        try {

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from tab_classe ");
            collection_classe = new ArrayList<>();
            while (rs.next()) {

                int a = rs.getInt("classe_id");
                String b = rs.getString("classe_nom");
                int c = rs.getInt("classe_niveau_id");
                int d = rs.getInt("classe_anneescolaire_id");
                System.out.println("a: " + a + " b: " + b + " c: " + c + " d: " + d);

                collection_classe.add(new Classe(a, b, c, d));

            }
        } catch (SQLException ex) {
            System.out.println("Probleme de chargement des classes ");
        }
    }
/**
 * Methode de fermeture de connection
 * @throws SQLException 
 */
    public void close_connection() throws SQLException {
        this.conn.close();
    }
/**
 * Getter de la collection de classe
 * @return 
 */
    public ArrayList<Classe> getCollection_classe() {
        return collection_classe;
    }
/** 
 * Methode de recherche de classe
 * @param e
 * @return
 * @throws NonExistingElement 
 */
    public Classe rechercher_classe(Classe e) throws NonExistingElement {
        for (Classe e1 : collection_classe) {
            if (e1.getId() == (e.getId()) && e1.getNom().equals(e.getNom())) {
                return e;
            }
        }
        throw new NonExistingElement("");
    }
/**
 * Methode de creation overrided
 * @param obj
 * @param a 
 */
    @Override
    public void creer(Classe obj, int a) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
/**
 * Methode de rechercher overrided
 * @param obj 
 */
    @Override
    public void recherche(Classe obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
