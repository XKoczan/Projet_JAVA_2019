/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.util.ArrayList;

/**
 *  Classe Classe
 * @author Guillaume
 */
public class Classe {
    // Attributs
    private int id;
    private int anneescolaire_id;
    private int niveau;
    private String nom;
    
    private ArrayList<Eleve> eleves = new ArrayList<>(); 
    /**
     * Constructeur surchargé
     * @param id
     * @param nom
     * @param niveau
     * @param anneescolaire_id 
     */
    public Classe(int id,String nom,int niveau, int anneescolaire_id ) {
        this.id = id;
        this.anneescolaire_id = anneescolaire_id;
        this.niveau = niveau;
        this.nom = nom;
    }
    /**
     * Constructeur surchargé
     * @param nom
     * @param niveau
     * @param anneescolaire_id 
     */
    public Classe(String nom,int niveau,int anneescolaire_id) {
        this.anneescolaire_id = anneescolaire_id;
        this.niveau = niveau;
        this.nom = nom;
    }
    /**
     * Constructeur par defaut
     */
    public Classe() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    /**
     * Getter du niveau
     * @return 
     */
    public int getNiveau() {
        return niveau;
    }

  

    public int getId() {
        return id;
    }

    public int getAnneescolaire_id() {
        return anneescolaire_id;
    }

    public String getNom() {
        return nom;
    }

    @Override
    public String toString() {
        return "Classe{" + "id=" + id + ", anneescolaire_id=" + anneescolaire_id + ", nom=" + nom + '}';
    }
    
    
}