/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.sql.SQLException;
import javax.swing.JLabel;

/**
 *
 * @author vithu
 */
public class FentreRefresh {
    int anneeScolaire;
    JLabel msg;
    int niveau;
          
    public FentreRefresh(int anneeScolaire) throws ClassNotFoundException, SQLException {
        FenetreStatNiveau n = new FenetreStatNiveau(anneeScolaire);
    }
    
    public FentreRefresh(JLabel msg) throws ClassNotFoundException, SQLException {
        FenetreStatNiveau n = new FenetreStatNiveau(msg);
    }
}
