/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.awt.*;
import javax.swing.JPanel;

/**
 *
 * @author vithu
 */
public class FondFenetre extends JPanel {
    Image image;
    /**
     * Constructeur
     */
    public FondFenetre() {
        image = getToolkit().getImage("pf_icon.png"); 
    }
    /**
     * Methode graphique
     * @param g 
     */
    @Override
    public void paintComponents(Graphics g) { 
        super.paintComponents(g); 
        g.drawImage(image, 0, 0, getWidth(), getHeight(), this); 
    } 
}
