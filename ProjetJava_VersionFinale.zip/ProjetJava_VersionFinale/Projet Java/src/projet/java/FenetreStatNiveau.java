/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author vithu
 */
public class FenetreStatNiveau implements KeyListener{
    //Attributs
    //Fenetre FenetreStatIndividus (Fenetre principale de cette classe)
    private final JFrame f = new JFrame("Part d'élèves dans un niveau");
    Box boxV = Box.createVerticalBox();
    JTextField anneeSaisie;
    JLabel msg;
    public int anneeScolaire = 2019;
    DAO_Eleve dao_eleve = new DAO_Eleve();
    JFreeChart histChart;
    ChartPanel histPanel;
     protected static Connection conn;
    

    //Constructeurs
    //Par défaut
    public FenetreStatNiveau(Connection conn) throws ClassNotFoundException, SQLException {
        FenetreStatNiveau.conn=conn;
        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //Fermeture de la fenetre si bouton croix rouge cliqué
        f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        f.getContentPane().add(boxV, BorderLayout.CENTER);
        
        
        //Barre de recherche en fonction de l'année saisie par l'utilisateur
        //initialisation et critere d'affichage label Année
        JLabel labelAnnee = new JLabel("Année : ");             //1 Label
        Font font = new Font("Arial",Font.PLAIN,18);
        labelAnnee.setFont(font);
        labelAnnee.setForeground(Color.black);
        //initialisation et critere d'affichage TextField
        anneeSaisie = new JTextField("Entrez l'année", 10);     //1 case de saisie
        anneeSaisie.setPreferredSize(new Dimension(10, 25) );
        labelAnnee.setLabelFor(anneeSaisie); //label lie a case de saisie
        //initialisation et critere d'affichage msg d'erreur
        msg = new JLabel("");        //2nd label pour afficher message d'erreur
        msg.setForeground(Color.red); //msg d'erreur affiche en rouge
        //Panel pour inclure les composants 
        JPanel panelSaisie = new JPanel(); 
        
        //ajout des composants dans panel
        panelSaisie.add(labelAnnee);
        panelSaisie.add(anneeSaisie);
        panelSaisie.add(msg);
        panelSaisie.setBackground(Color.white);
        //On ajoute le panel de saisie au box principal vertical 
        boxV.add(panelSaisie);
        //si on enfonce la touche entrée
        anneeSaisie.addKeyListener(this);
        
        //on recupere le nombre d'eleves dans chaque niveau donne
         //Création Histogramme
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dao_eleve = new DAO_Eleve(conn,null);
        //on entre le nombre d'eleves dans un niveau donne
        dataset.addValue(dao_eleve.nbElevesNiveau(1, anneeScolaire -1), "ING 1", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(2, anneeScolaire -1), "ING 2", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(3, anneeScolaire -1), "ING 3", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(4, anneeScolaire -1), "ING 4", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(5, anneeScolaire -1), "ING 5", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(1, anneeScolaire), "ING 1", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(2, anneeScolaire), "ING 2", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(3, anneeScolaire), "ING 3", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(4, anneeScolaire), "ING 4", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(5, anneeScolaire), "ING 5", Integer.toString(anneeScolaire));
        //initialisation du JFreeChart 
        histChart = ChartFactory.createBarChart("Part d'élèves dans chaque niveau", "", "Nombres d'élèves", dataset, PlotOrientation.VERTICAL, true, true, false);
        histPanel = new ChartPanel(histChart);
        boxV.add(histPanel);
        
        
        //fenetre rendu visible
        f.setVisible(true);
        System.out.println(anneeScolaire);
    }
    
    public FenetreStatNiveau(int anneeScolaire) throws ClassNotFoundException, SQLException {

        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //Fermeture de la fenetre si bouton croix rouge cliqué
        f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        f.getContentPane().add(boxV, BorderLayout.CENTER);
        
        
        //Barre de recherche en fonction de l'année saisie par l'utilisateur
        JLabel labelAnnee = new JLabel("Année : ");             //1 Label
        anneeSaisie = new JTextField("Entrez l'année", 10);     //1 case de saisie
        labelAnnee.setLabelFor(anneeSaisie); //label lie a case de saisie
        JPanel panelSaisie = new JPanel();  //Panel pour inclure les composants 
        msg = new JLabel("");        //2nd label pour afficher message d'erreur
        msg.setForeground(Color.red); //msg d'erreur affiche en rouge
        
        //ajout des composants dans panel
        panelSaisie.add(labelAnnee);
        panelSaisie.add(anneeSaisie);
        panelSaisie.add(msg);
        //On ajoute le panel de saisie au box principal vertical 
        boxV.add(panelSaisie);
        //si on enfonce la touche entrée
        anneeSaisie.addKeyListener(this);
        
        //on recupere le nombre d'eleves dans chaque niveau donne
         //Création Histogramme
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dao_eleve = new DAO_Eleve(conn,null);
        //on entre le nombre d'eleves dans un niveau donne
        dataset.addValue(dao_eleve.nbElevesNiveau(1, anneeScolaire -1), "ING 1", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(2, anneeScolaire -1), "ING 2", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(3, anneeScolaire -1), "ING 3", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(4, anneeScolaire -1), "ING 4", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(5, anneeScolaire -1), "ING 5", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(1, anneeScolaire), "ING 1", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(2, anneeScolaire), "ING 2", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(3, anneeScolaire), "ING 3", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(4, anneeScolaire), "ING 4", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(5, anneeScolaire), "ING 5", Integer.toString(anneeScolaire));
        //initialisation du JFreeChart 
        histChart = ChartFactory.createBarChart("Part d'élèves dans chaque niveau", "", "Nombres d'élèves", dataset, PlotOrientation.VERTICAL, true, true, false);
        histPanel = new ChartPanel(histChart);
        boxV.add(histPanel);
        
        //fenetre rendu visible
        f.setVisible(true);
    }

    FenetreStatNiveau(JLabel msg) {
        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //Fermeture de la fenetre si bouton croix rouge cliqué
        f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        f.getContentPane().add(boxV, BorderLayout.CENTER);
        
        
        //Barre de recherche en fonction de l'année saisie par l'utilisateur
        JLabel labelAnnee = new JLabel("Année : ");             //1 Label
        anneeSaisie = new JTextField("Entrez l'année", 10);     //1 case de saisie
        labelAnnee.setLabelFor(anneeSaisie); //label lie a case de saisie
        JPanel panelSaisie = new JPanel();  //Panel pour inclure les composants 
        msg.setForeground(Color.red); //msg d'erreur affiche en rouge
        
        //ajout des composants dans panel
        panelSaisie.add(labelAnnee);
        panelSaisie.add(anneeSaisie);
        panelSaisie.add(msg);
        //On ajoute le panel de saisie au box principal vertical 
        boxV.add(panelSaisie);
        //si on enfonce la touche entrée
        anneeSaisie.addKeyListener(this);
        
        //on recupere le nombre d'eleves dans chaque niveau donne
         //Création Histogramme
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dao_eleve = new DAO_Eleve(conn,null);
        //on entre le nombre d'eleves dans un niveau donne
        dataset.addValue(dao_eleve.nbElevesNiveau(1, anneeScolaire -1), "ING 1", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(2, anneeScolaire -1), "ING 2", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(3, anneeScolaire -1), "ING 3", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(4, anneeScolaire -1), "ING 4", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(5, anneeScolaire -1), "ING 5", Integer.toString(anneeScolaire - 1));
        dataset.addValue(dao_eleve.nbElevesNiveau(1, anneeScolaire), "ING 1", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(2, anneeScolaire), "ING 2", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(3, anneeScolaire), "ING 3", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(4, anneeScolaire), "ING 4", Integer.toString(anneeScolaire));
        dataset.addValue(dao_eleve.nbElevesNiveau(5, anneeScolaire), "ING 5", Integer.toString(anneeScolaire));
        //initialisation du JFreeChart 
        histChart = ChartFactory.createBarChart("Part d'élèves dans chaque niveau", "", "Nombres d'élèves", dataset, PlotOrientation.VERTICAL, true, true, false);
        histPanel = new ChartPanel(histChart);
        boxV.add(histPanel);
        
        //fenetre rendu visible
        f.setVisible(true);
    }
    
    //Méthodes
    /**
     * Getter fenetre
     * @return Fenetre
     */
    public JFrame getFenetre(){
        return this.f;
    }

    //Méthodes lorsque la touche "entrée" est appuye (associe a KeyListener)
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            try {
                //si l'annee entré par l'utilisateur existe bien dans la BDD
                if(dao_eleve.VerifAnnee(Integer.parseInt(anneeSaisie.getText())) == true){
                    anneeScolaire = Integer.parseInt(anneeSaisie.getText()) ; //on redéfinit l'année avec la valeur entrée
                    f.setVisible(false);
                    //on "rafraichit" la fenetre en reouvrant la meme fenetre avec l'annee mentionne
                    try {
                        FentreRefresh fen= new FentreRefresh(anneeScolaire);
                    } 
                    catch (ClassNotFoundException ex) {
                        System.out.println("ERREUR : Incident lors du chargement");
                    }
                    catch (SQLException ex) {
                        System.out.println("ERREUR : Problème lors du 'click'");
                    }
                }
                else{
                    msg = new JLabel("Données non fournies pour l'année indiquée");
                    f.setVisible(false);
                    //on "rafraichit" la fenetre en reouvrant la meme fenetre avec le msg d'erreur
                    try {
                        FentreRefresh fen= new FentreRefresh(msg);
                    } 
                    catch (ClassNotFoundException ex) {
                        System.out.println("ERREUR : Incident lors du chargement");
                    }
                    catch (SQLException ex) {
                        System.out.println("ERREUR : Problème lors du 'click'");
                    }
                }
            } 
            catch (SQLException ex) {
                System.out.println("ERREUR lors de la recherche des données");
            } 
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
