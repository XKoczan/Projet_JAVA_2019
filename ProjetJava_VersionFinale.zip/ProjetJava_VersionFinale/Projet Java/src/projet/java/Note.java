/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author xavie
 */
public class Note {
    private int note;
    private int id;
    private String appreciation;
    /**
     * Constructeur
     */
    public Note(){};
    /**
     * Constructeur surchargé
     * @param note
     * @param appreciation
     * @param id 
     */
    public Note(int note, String appreciation,int id){
        this.id=id;
        this.note=note;
        this.appreciation=appreciation;
    };
/**
 * Getter de valeur de note
 * @return 
 */
    public int getNote() {
        return note;
    }
/**
 * Getter d'appréciation
 * @return 
 */
    public String getAppreciation() {
        return appreciation;
    }
/**
 * Setter de valeur de note
 * @param note 
 */
    public void setNote(int note) {
        this.note = note;
    }
/**
 * Methode de getter d'id
 * @return 
 */
    public int getId() {
        return this.id;
    }
/**
 * Methode de setting d'appréciatino
 * @param message 
 */

    public void setAppreciation(String message) {
        this.appreciation=message; //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
