/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.sql.Connection;

/**
 *  Classe abstraite DAO
 * @author guifl
 * @param <T>
 */
public abstract class DAO<T> {

    protected Connection conn = null;
/**
 * Constructeur par defaut
 */
    public DAO() {
         }

    /**
     * Méthode de création
     *
     * @param obj
     * @param a
     */
    public abstract void creer(T obj, int a);
    
    /**
     * Méthode pour effacer
     *
     * @param obj
     */
    public abstract void supprimer(T obj);

    /**
     * Méthode de mise à jour
     *
     * @param obj
     */
    public abstract void modifier(T obj);

    /**
     * Méthode de recherche des informations
     *
     */
    public abstract void chargement();
    /**
     * Methode de rechercher
     * @param obj 
     */
    public abstract void recherche(T obj);
}
