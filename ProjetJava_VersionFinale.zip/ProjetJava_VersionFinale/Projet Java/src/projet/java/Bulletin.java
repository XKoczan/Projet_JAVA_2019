/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import java.util.ArrayList;

/**
 * Classe Bulletin
 * @author xavie
 */
public class Bulletin {
    
    public ArrayList <DetailBulletin> details_collection = new ArrayList<>();  
    private int id;
    private String appreciation;
    private Eleve eleve;
    /**
     * Constructeur par defaut
     */
    public Bulletin(){};
    /**
     * Constructeur surchargé
     * @param appreciation
     * @param id
     * @param e
     * @param details_collection 
     */
    public Bulletin(String appreciation, int id, Eleve e,ArrayList <DetailBulletin> details_collection){
        this.id=id;
        this.appreciation=appreciation;        
        this.eleve=e;
        this.details_collection= details_collection;
    };
    /**
     * Getter de la collection
     * @return 
     */
    public ArrayList<DetailBulletin> getDetails_collection() {
        return details_collection;
    }
    /**
     * Getter d'id
     * @return 
     */
    public int getId() {
        return id;
    }
    /**
     * Getter d'appreciation
     * @return 
     */
    public String getAppreciation() {
        return appreciation;
    }
    /**
     * Getter d'eleve
     * @return 
     */
    public Eleve getEleve() {
        return eleve;
    }
    
}
