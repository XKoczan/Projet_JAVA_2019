/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import javax.swing.*;
import org.jfree.chart.*;
import org.jfree.data.general.DefaultPieDataset;

/**
 * Reporting
 * @author vithu
 * Source: JmDoudoux (https://www.jmdoudoux.fr/java/dej/chap-bibliotheques-free.htm)
 */
public class FenetreStatIndividus implements ActionListener{
    //Attributs
    //Fenetre FenetreStatIndividus (Fenetre principale de cette classe)
    private final JFrame f = new JFrame("Part d'individus");
    

    //Constructeurs
    public FenetreStatIndividus() throws ClassNotFoundException, SQLException {

        //On fixe la taille de la fenetre
        f.setSize(800, 600);
        //on cree un panel dans la fenetre
        JPanel panel = new JPanel(new BorderLayout());
        f.setContentPane(panel);
        //Fermeture de la fenetre si bouton croix rouge cliqué
        f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        
        //on recupere le nombre d'individus dans tab_personne de la BDD
        DAO_Eleve dao_eleve = new DAO_Eleve();
        DAO_Professeur dao_prof = new DAO_Professeur();
        
        //Nécessaire pour la compilation de la source code
        DefaultPieDataset division = new DefaultPieDataset();
        //on définit les différentes parts du camembert
        double preCalcul = 100/(dao_eleve.nbElevesTable() + dao_prof.nbProfTable());
        division.setValue("Eleves " + dao_eleve.nbElevesTable()*preCalcul + "%", dao_eleve.nbElevesTable());
        division.setValue("Professeurs " + dao_prof.nbProfTable()*preCalcul + "%", dao_prof.nbProfTable());
        //Création du camembert
        JFreeChart camembert = ChartFactory.createPieChart("Part d'individus dans l'école", division, true, true, true);
        ChartPanel camPanel = new ChartPanel(camembert);
        panel.add(camPanel);
        f.setVisible(true);
    }
    
    //Méthodes
    /**
     * Getter fenetre
     * @return Fenetre
     */
    public JFrame getFenetre(){
        return this.f;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
       
    }

    
    
    
}
