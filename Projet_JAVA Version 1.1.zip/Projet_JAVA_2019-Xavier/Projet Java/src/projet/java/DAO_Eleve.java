/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

import Exceptions.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Guillaume
 */
public class DAO_Eleve extends DAO<Eleve> {

    private ArrayList<Eleve> collection_eleve = new ArrayList<>();

    public DAO_Eleve() {
        super();
        chargement();
    }

    @Override
    public void creer(Eleve obj, int classe) {
        try {

            PreparedStatement stmt = conn.prepareStatement("insert into tab_personne(personne_nom,personne_prenom,personne_type) values(?,?,?)");

            stmt.setObject(1, obj.getNom(), Types.VARCHAR);
            stmt.setObject(2, obj.getPrenom(), Types.VARCHAR);
            stmt.setObject(3, obj.getType(), Types.VARCHAR);
            stmt.executeUpdate();

            stmt = conn.prepareStatement("SELECT personne_id FROM tab_personne WHERE personne_nom = ? and personne_prenom = ?");
//           System.out.println("1");//Test
            stmt.setString(1, obj.getNom());
            stmt.setString(2, obj.getPrenom());
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int id = rs.getInt("personne_id");
            System.out.println("IDD:" + id + "| Classe:" + classe);

            stmt = conn.prepareStatement("insert into tab_inscription(inscription_classe_id,inscription_personne_id) values(?,?)");
            stmt.setObject(1, classe, Types.INTEGER);
            stmt.setObject(2, id, Types.INTEGER);
            stmt.executeUpdate();

            stmt = conn.prepareStatement("SELECT inscription_id FROM tab_inscription WHERE inscription_personne_id = ?");
//           System.out.println("1");//Test
            stmt.setObject(1, id);
            rs = stmt.executeQuery();
            rs.next();
            int id2 = rs.getInt("inscription_id");
            System.out.println("IDD2:" + id2 + "| Classe:" + classe);
            
            for (int i = 1; i <= 3; i++) {
                stmt = conn.prepareStatement("insert into tab_bulletin(bulletin_trimestre_id,bulletin_inscription_id,bulletin_appreciation) values(?,?,'A renseigner')");
                stmt.setObject(1, i, Types.INTEGER);
                System.out.println("1");
                stmt.setObject(2, id2, Types.INTEGER);
                System.out.println("2");
                stmt.executeUpdate();
            }

        } catch (SQLException ex) {
            System.out.println("Probleme de creation eleve");
        }

    }

    /*On crée un élement dans la BDD par la requete SQL insert into**/
    @Override
    public void supprimer(Eleve obj) {
        try {

            PreparedStatement stmt = conn.prepareStatement("SELECT inscription_id FROM tab_inscription WHERE inscription_personne_id = ?");
//           System.out.println("1");//Test
            stmt.setObject(1, obj.getId());
            ResultSet rs = stmt.executeQuery();
            rs.next();
            int id2 = rs.getInt("inscription_id");

            stmt = conn.prepareStatement("DELETE FROM tab_bulletin where bulletin_inscription_id = ?");
            stmt.setObject(1, id2, Types.INTEGER);
            stmt.executeUpdate();

            stmt = conn.prepareStatement("DELETE FROM tab_inscription where inscription_personne_id = ?");
            stmt.setObject(1, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

            stmt = conn.prepareStatement("DELETE FROM tab_personne where personne_id = ?");
            stmt.setObject(1, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Probleme de suppression");
        }
    }

    /*On modifie un élement dans la BDD par la requete SQL Update set en utilisant where pour indiquer l'élément à modifier, on utilise l'id**/
    @Override
    public void modifier(Eleve obj) {
        try {

            // ID ave cla classe ELeve
//            id = obj.getId();
            PreparedStatement stmt = conn.prepareStatement("Update tab_personne set personne_nom = ? ,personne_prenom = ? ,personne_type = ? where personne_id = ? ");
            stmt.setObject(1, obj.getNom(), Types.VARCHAR);
            stmt.setObject(2, obj.getPrenom(), Types.VARCHAR);
            stmt.setObject(3, obj.getType(), Types.VARCHAR);
            stmt.setObject(4, obj.getId(), Types.INTEGER);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Probleme de modification");
        }
    }

    @Override
    public final void chargement() {

        try {

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from tab_personne where personne_type like 'etu'");
            collection_eleve = new ArrayList<>();
            while (rs.next()) {

                int a = rs.getInt("personne_id");
                String b = rs.getString("personne_nom");
                String c = rs.getString("personne_prenom");
                String d = rs.getString("personne_type");
                System.out.println("a: " + a + " b: " + b + " c: " + c + " d: " + d);

                collection_eleve.add(new Eleve(a, b, c));

            }
        } catch (SQLException ex) {
            Logger.getLogger(DAO_Eleve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void close_connection() throws SQLException {
        this.conn.close();
    }

    public ArrayList<Eleve> getCollection_eleve() {
        return collection_eleve;
    }

    public Eleve rechercher_eleve(Eleve e) throws NonExistingElement {
        for (Eleve e1 : collection_eleve) {
            if (e1.getNom().equals(e.getNom()) && e1.getPrenom().equals(e.getPrenom())) {
                return e;
            }
        }
        throw new NonExistingElement("");
    }
    
    /**
     * Comptre le nombre d'eleves dans tab_personne
     * @return entier correspondant au nombre d'eleves
     */
    public Integer nbElevesTable(){
        try {

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select * from tab_personne where personne_type like 'etu'"); //resultat de la requete
            
            if(rs.last()){ //une fois le dernier resultat atteint
                return rs.getRow(); //retourne le nombre de lignes d'eleves dans la table
            } 
            else {
                return 0; 
            }
        } 
        catch (SQLException ex) { 
            System.out.println("ERREUR : Problème lors du calcul !");
        }
        return 0;
    }
    
    /**
     * Comptre le nombre d'eleves dans un niveau
     * @param niveau
     * @param anneeScolaire
     * @return entier correspondant au nombre d'eleves dans un niveau
     */
    public Integer nbElevesNiveau(int niveau, int anneeScolaire){
        try {
            //on cherche à afficher tous les eleves qui sont en ING i (niveau i)
            PreparedStatement stmt = conn.prepareStatement("select * from tab_inscription INNER JOIN tab_classe ON inscription_classe_id = classe_id where classe_niveau_id = ? and classe_anneescolaire_id = ?");
            //le niveau désirée est le niveau i
            stmt.setInt(1, niveau);
            stmt.setInt(2, anneeScolaire);
            ResultSet rs = stmt.executeQuery();

            if(rs.last()){ //une fois le dernier resultat atteint
                return rs.getRow(); //retourne le nombre de lignes d'eleves dans la table
            } 
            else {
                return 0; //le dernier resultat n'a pas ete atteint
            }
        } 
        catch (SQLException ex) { 
            System.out.println("ERREUR : Problème lors du calcul !");
        }
        return 0;
    }
    
    /**
     * Comptre le nombre d'eleves dans un niveau
     * @param classe
     * @param anneeScolaire
     * @return entier correspondant au nombre d'eleves dans un niveau
     */
    public Integer nbElevesClasse(int classe, int niveau, int anneeScolaire){
        try {
            //on cherche à afficher tous les eleves qui sont en ING i (niveau i)
            PreparedStatement stmt = conn.prepareStatement("select * from tab_inscription INNER JOIN tab_classe ON inscription_classe_id = classe_id where classe_niveau_id = ? and classe_id = ? and classe_anneescolaire_id = ?");
            //le niveau désirée est le niveau i
            stmt.setInt(1, niveau);
            stmt.setInt(2, classe);
            stmt.setInt(3, anneeScolaire);
            ResultSet rs = stmt.executeQuery();

            if(rs.last()){ //une fois le dernier resultat atteint
                return rs.getRow(); //retourne le nombre de lignes d'eleves dans la table
            } 
            else {
                return 0; //le dernier resultat n'a pas ete atteint
            }
        } 
        catch (SQLException ex) { 
            System.out.println("ERREUR : Problème lors du calcul !");
        }
        return 0;
    }
    
    /**
     * Verifie si l'année est dans la BDD
     * @param anneeScolaire
     * @return verif booleen
     * @throws SQLException 
     */
    public boolean VerifAnnee(int anneeScolaire) throws SQLException {
        //booleen qui indiquera si anneeScolaire existe ou non dans la BDD
        boolean verif = false;
        try{
            //on recupere toutes les annees presentes dans la BDD
            PreparedStatement stmt = conn.prepareStatement("select * from tab_anneescolaire");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            //on verfie si anneeScolaire exite dans la BDD
            do{
                if (anneeScolaire == rs.getInt("anneescolaire_id")) //si anneeScolaire est dans les resultats
                    verif = true; //verif devient vrai (anneescolaire existe)
            }while(verif != true && rs.next()); //tant qu'on n'a pas trouvé anneeScolaire et qu'on n'a pas atteint la derniere ligne de resultats
            
        }
        catch (SQLException ex) { 
            System.out.println("ERREUR lors de la recherche !");
        }
        return verif;
    }
}
