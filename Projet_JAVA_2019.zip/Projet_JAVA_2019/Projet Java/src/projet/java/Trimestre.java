/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author vithu
 */
public class Trimestre {
    //Attributs
    int id;
    int numero;
    int debut;
    int fin;
    
    //Constructeurs
    public Trimestre() {
        
    }
    
    public Trimestre(int id, int numero, int debut, int fin) {
        this.id = id;
        this.numero = numero;
        this.debut = debut;
        this.fin = fin;
    }
    
    //getters
    public int getId() {
        return id;
    }
    
    //setters
    public void setId(int id) {
        this.id = id;
    }
    
    

    

    
}
