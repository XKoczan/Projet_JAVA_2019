/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author vithu
 */
public class Niveau {
    //Attributs
    int id;
    String nom;
    
    //Constructeurs
    public Niveau() {
        
    }

    public Niveau(int id, String nom) {
        this.id = id;
        this.nom = nom;
    }
    
    //Getters
    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }
    
    //Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
