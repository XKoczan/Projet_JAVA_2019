/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author vithu
 */
public class Evaluation {
    //Attributs
    int id;
    int note;
    String appreciation;

    //Constructeurs
    public Evaluation() {

    }
    
    public Evaluation(int id, int note, String appreciation) {
        this.id = id;
    }
    
    //Getter
    public int getId() {
        return id;
    }

    public int getNote() {
        return note;
    }

    public String getAppreciation() {
        return appreciation;
    }
    
    //Setter
    public void setId(int id) {
        this.id = id;
    }

    public void setNote(int note) {
        this.note = note;
    }

    public void setAppreciation(String appreciation) {
        this.appreciation = appreciation;
    }
    
}
