/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet.java;

/**
 *
 * @author vithu
 */
public class DetailBulletin {
    //Attributs
    int id;
    String appreciation;

    //Constructeurs
    public DetailBulletin() {

    }
    
    public DetailBulletin(int id, String appreciation) {
        this.id = id;
    }
    
    //Getter
    public int getId() {
        return id;
    }

    public String getAppreciation() {
        return appreciation;
    }
    
    //Setter
    public void setId(int id) {
        this.id = id;
    }

    public void setAppreciation(String appreciation) {
        this.appreciation = appreciation;
    }
    
}
